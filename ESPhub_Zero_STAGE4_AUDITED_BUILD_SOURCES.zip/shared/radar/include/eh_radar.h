#pragma once
#include <array>
#include <cstddef>
#include <cstdint>

namespace esphub {
// RF change detector. Never reports a person, identity, body pose or true location.
enum class RfState : uint8_t { NoData, Calibrating, Quiet, Changed, Degraded };
struct Observation {
    RfState state = RfState::NoData;
    uint8_t score = 0;
    uint32_t accepted_frames = 0;
    uint32_t dropped_frames = 0;
    uint32_t baseline_windows = 0;
    uint16_t active_carriers = 0;
};
struct Config {
    uint32_t min_frames_per_window = 12;
    uint32_t baseline_windows = 20;
    float change_threshold = 0.17f;    // relative power-profile deviation
    float quiet_threshold = 0.08f;
    uint8_t change_streak = 3;
    uint8_t quiet_streak = 5;
};
class RadarCore {
public:
    explicit RadarCore(Config config = {});
    // Called from a lower-priority worker, never from the Wi-Fi callback.
    // Input is interleaved signed I/Q CSI, even-length, up to 512 bytes.
    bool ingest_iq(const int8_t* iq, size_t bytes);
    // Window boundary is controlled by the firmware (nominal 1 second).
    Observation complete_window();
    void reset_baseline();
    const Observation& last() const noexcept { return last_; }
private:
    static constexpr size_t kBands = 8;
    Config config_;
    std::array<double, kBands> baseline_{};
    std::array<double, kBands> sum_{};
    std::array<double, kBands> window_{};
    uint32_t frame_count_ = 0;
    uint32_t dropped_ = 0;
    uint32_t calibrated_ = 0;
    uint8_t change_count_ = 0;
    uint8_t quiet_count_ = 0;
    bool changed_ = false;
    Observation last_{};
};
} // namespace esphub
