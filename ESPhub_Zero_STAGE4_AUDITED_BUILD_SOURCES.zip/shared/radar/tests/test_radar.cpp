#include "eh_radar.h"
#include <array>
#include <cassert>
#include <cstdio>
using namespace esphub;
static void feed(RadarCore& r, bool changed=false, int frames=16) {
    std::array<int8_t,128> frame{};
    for (int j=0;j<frames;++j) {
        for (size_t i=0;i<frame.size()/2;++i) {
            frame[2*i] = static_cast<int8_t>(changed && i<32 ? 45 : 19);
            frame[2*i+1] = static_cast<int8_t>(changed && i<32 ? 45 : 3);
        }
        assert(r.ingest_iq(frame.data(),frame.size()));
    }
}
int main() {
    RadarCore r(Config{12,4,0.17f,0.08f,3,5});
    assert(r.complete_window().state==RfState::NoData);
    assert(!r.ingest_iq(nullptr,100));
    for(int i=0;i<4;++i) { feed(r); assert(r.complete_window().state==RfState::Calibrating); }
    feed(r); assert(r.complete_window().state==RfState::Quiet);
    for(int i=0;i<2;++i) { feed(r,true); assert(r.complete_window().state==RfState::Quiet); }
    feed(r,true); assert(r.complete_window().state==RfState::Changed);
    for(int i=0;i<4;++i) { feed(r); assert(r.complete_window().state==RfState::Changed); }
    feed(r); assert(r.complete_window().state==RfState::Quiet);
    for(int i=0;i<2;++i) assert(r.complete_window().state==RfState::NoData);
    r.reset_baseline(); assert(r.last().state==RfState::NoData);
    puts("PASS: RF detector calibration, hysteresis, missing data, reset");
}
