#include "eh_radar.h"
#include <algorithm>
#include <cmath>

namespace esphub {
RadarCore::RadarCore(Config c) : config_(c) {}
void RadarCore::reset_baseline() {
    baseline_.fill(0.0); sum_.fill(0.0); window_.fill(0.0);
    frame_count_ = dropped_ = calibrated_ = 0;
    change_count_ = quiet_count_ = 0; changed_ = false;
    last_ = {};
}
bool RadarCore::ingest_iq(const int8_t* iq, size_t bytes) {
    if (!iq || bytes < 32 || (bytes & 1) || bytes > 512) {
        ++dropped_;
        return false;
    }
    const size_t carriers = bytes / 2;
    std::array<double,kBands> bands{};
    std::array<uint16_t,kBands> counts{};
    for (size_t i=0; i<carriers; ++i) {
        size_t band = std::min(kBands-1, i*kBands/carriers);
        double re = static_cast<double>(iq[i*2]);
        double im = static_cast<double>(iq[i*2+1]);
        bands[band] += re*re + im*im;
        ++counts[band];
    }
    // Normalize by mean across bands: reduces sensitivity to uniform TX power changes.
    double total = 0;
    for (size_t b=0; b<kBands; ++b) {
        bands[b] /= std::max<uint16_t>(1, counts[b]);
        total += bands[b];
    }
    if (total <= 0) { ++dropped_; return false; }
    for (size_t b=0; b<kBands; ++b) sum_[b] += bands[b] / total;
    ++frame_count_;
    last_.active_carriers = static_cast<uint16_t>(carriers);
    return true;
}
Observation RadarCore::complete_window() {
    last_.accepted_frames = frame_count_;
    last_.dropped_frames = dropped_;
    last_.baseline_windows = calibrated_;
    if (frame_count_ < config_.min_frames_per_window) {
        last_.state = frame_count_ ? RfState::Degraded : RfState::NoData;
        last_.score = 0;
    } else {
        for (size_t i=0;i<kBands;++i) window_[i] = sum_[i]/frame_count_;
        if (calibrated_ < config_.baseline_windows) {
            for (size_t i=0;i<kBands;++i) baseline_[i] += window_[i];
            ++calibrated_;
            if (calibrated_ == config_.baseline_windows)
                for (double& x : baseline_) x /= calibrated_;
            last_.state = RfState::Calibrating;
            last_.baseline_windows = calibrated_;
            last_.score = 0;
        } else {
            double diff = 0;
            for(size_t i=0;i<kBands;++i) diff += std::abs(window_[i]-baseline_[i]);
            // L1 distance in [0,2]. This is an RF-change indicator, not confidence.
            const float index = static_cast<float>(diff*0.5);
            last_.score = static_cast<uint8_t>(std::clamp(index*350.0f, 0.0f, 100.0f));
            if (index >= config_.change_threshold) {
                quiet_count_ = 0;
                if (change_count_ < 255) ++change_count_;
                if (change_count_ >= config_.change_streak) changed_ = true;
            } else if (index <= config_.quiet_threshold) {
                change_count_ = 0;
                if (quiet_count_ < 255) ++quiet_count_;
                if (quiet_count_ >= config_.quiet_streak) changed_ = false;
                // Update baseline only when quiet; avoids learning a moving object as empty-room baseline.
                if (!changed_) for(size_t i=0;i<kBands;++i)
                    baseline_[i] = baseline_[i]*0.997 + window_[i]*0.003;
            }
            last_.state = changed_ ? RfState::Changed : RfState::Quiet;
        }
    }
    frame_count_=0; dropped_=0; sum_.fill(0.0);
    return last_;
}
} // namespace esphub
