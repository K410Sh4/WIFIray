#include "eh_wire.h"
#include <cassert>
#include <cstring>
#include <iostream>
int main(){
 using namespace esphub;
 Telemetry t{};t.node=2;t.state=3;t.score=89;t.rssi=-62;t.carriers=48;
 t.accepted=123;t.rejected=7;t.queue_drops=3;t.baseline=21;t.uptime_ms=0x0123456789abcdefULL;
 uint8_t p[kTelemetryBytes]={};assert(encodeTelemetry(t,p,sizeof(p)));
 assert(p[0]==1&&p[4]==static_cast<uint8_t>(-62)&&p[6]==0&&p[7]==48);
 assert(p[24]==0x01&&p[31]==0xef);
 Telemetry d{};assert(decodeTelemetry(p,sizeof(p),d));assert(d.uptime_ms==t.uptime_ms&&d.rssi==t.rssi&&d.accepted==123);
 assert(!decodeTelemetry(p,sizeof(p)-1,d));p[5]=1;assert(!decodeTelemetry(p,sizeof(p),d));
 p[5]=0;p[3]=101;assert(!decodeTelemetry(p,sizeof(p),d));
 p[3]=89;p[1]=4;assert(!decodeTelemetry(p,sizeof(p),d));
 uint8_t hello[kHelloBytes]={'E','H','U','B',1,1,2};assert(validHello(hello,sizeof(hello),2));
 assert(!validHello(hello,sizeof(hello)-1,2));hello[6]=3;assert(!validHello(hello,sizeof(hello),2));
 std::cout<<"wire serialization and strict envelope tests PASS\n";
}
