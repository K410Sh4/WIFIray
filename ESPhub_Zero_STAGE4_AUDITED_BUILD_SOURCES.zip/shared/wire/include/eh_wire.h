#pragma once
#include <cstddef>
#include <cstdint>

namespace esphub {
inline constexpr uint16_t kUplinkPort = 42722;
inline constexpr size_t kTelemetryBytes = 32;
inline constexpr size_t kHeaderBytes = 30;
inline constexpr size_t kTagBytes = 16;
inline constexpr size_t kFrameBytes = kHeaderBytes+kTelemetryBytes+kTagBytes;
inline constexpr size_t kHelloBytes = 23;     // EHUB v1 / 0x01 / node / clientNonce16
inline constexpr size_t kChallengeBytes = 71; // EHUB v1 / 0x02 / node / clientNonce16 / deviceNonce16 / MAC32
inline constexpr size_t kProofBytes = 39;     // EHUB v1 / 0x03 / node / MAC32
inline constexpr uint8_t kWireVersion = 1;

inline void be16(uint8_t* dst, uint16_t n){dst[0]=n>>8;dst[1]=n;}
inline void be32(uint8_t* dst, uint32_t n){for(int i=3;i>=0;--i){dst[i]=n&255;n>>=8;}}
inline void be64(uint8_t* dst, uint64_t n){for(int i=7;i>=0;--i){dst[i]=n&255;n>>=8;}}
inline uint16_t read16(const uint8_t* p){return (uint16_t(p[0])<<8)|p[1];}
inline uint32_t read32(const uint8_t* p){return (uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|p[3];}
inline uint64_t read64(const uint8_t* p){uint64_t n=0;for(int i=0;i<8;++i)n=(n<<8)|p[i];return n;}

struct Telemetry {
    uint8_t node=0;
    uint8_t state=0; // 0 NoData, 1 Calibrating, 2 Quiet, 3 Changed, 4 Degraded, 5 ReferenceOnly
    uint8_t score=0;
    int8_t rssi=-127;
    uint16_t carriers=0;
    uint32_t accepted=0;
    uint32_t rejected=0;
    uint32_t queue_drops=0;
    uint32_t baseline=0;
    uint64_t uptime_ms=0;
};
inline bool validNode(int node){return node>=1&&node<=3;}
inline bool encodeTelemetry(const Telemetry& t, uint8_t* out, size_t n){
    if(n!=kTelemetryBytes||!validNode(t.node)||t.state>5||t.score>100)return false;
    out[0]=1;out[1]=t.node;out[2]=t.state;out[3]=t.score;
    out[4]=static_cast<uint8_t>(t.rssi);out[5]=0;
    be16(out+6,t.carriers);be32(out+8,t.accepted);be32(out+12,t.rejected);
    be32(out+16,t.queue_drops);be32(out+20,t.baseline);be64(out+24,t.uptime_ms);
    return true;
}
inline bool decodeTelemetry(const uint8_t* p,size_t n,Telemetry& out){
    if(!p||n!=kTelemetryBytes||p[0]!=1||!validNode(p[1])||p[2]>5||p[3]>100||p[5]!=0)return false;
    out.node=p[1];out.state=p[2];out.score=p[3];out.rssi=static_cast<int8_t>(p[4]);
    out.carriers=read16(p+6);out.accepted=read32(p+8);out.rejected=read32(p+12);
    out.queue_drops=read32(p+16);out.baseline=read32(p+20);out.uptime_ms=read64(p+24);return true;
}
inline bool validHello(const uint8_t* p,size_t n,int id){
    return p&&n==kHelloBytes&&p[0]=='E'&&p[1]=='H'&&p[2]=='U'&&p[3]=='B'&&
        p[4]==1&&p[5]==1&&p[6]==id;
}
inline bool validProof(const uint8_t* p,size_t n,int id){
    return p&&n==kProofBytes&&p[0]=='E'&&p[1]=='H'&&p[2]=='U'&&p[3]=='B'&&
        p[4]==1&&p[5]==3&&p[6]==id;
}
} // namespace esphub
