#include "eh_reference.h"
#include <cassert>
#include <cstdio>
int main(){
 auto x=esphub::make_reference(0x01234567,0x0123456789abcdefULL);
 assert(x[0]=='E'&&x[1]=='H'&&x[2]=='R'&&x[3]=='F');
 assert(x[4]==1&&x[7]==0x67&&x[8]==1&&x[15]==0xef);
 assert(esphub::valid_response(x.data(),x.data(),x.size()));
 assert(!esphub::valid_reference(nullptr,x.size()));
 assert(!esphub::valid_reference(x.data(),x.size()-1));
 auto wrong=x;wrong[9]^=1;assert(!esphub::valid_response(x.data(),wrong.data(),x.size()));
 wrong=x;wrong[0]='X';assert(!esphub::valid_reference(wrong.data(),wrong.size()));
 puts("PASS: reference frame format and untrusted response validation");
}
