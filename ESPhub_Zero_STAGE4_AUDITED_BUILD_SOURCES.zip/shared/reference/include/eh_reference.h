#pragma once
#include <array>
#include <cstdint>
#include <cstddef>

namespace esphub {
// RF stimulus only. NEVER parse this as authenticated command/telemetry.
inline constexpr size_t kRefBytes = 96;
using RefPacket = std::array<uint8_t, kRefBytes>;
inline RefPacket make_reference(uint32_t seq, uint64_t ms) noexcept {
    RefPacket f{};
    f[0]='E'; f[1]='H'; f[2]='R'; f[3]='F';
    for(int i=0;i<4;++i)f[4+i]=static_cast<uint8_t>(seq>>(24-8*i));
    for(int i=0;i<8;++i)f[8+i]=static_cast<uint8_t>(ms>>(56-8*i));
    return f;
}
inline bool valid_reference(const uint8_t* f, size_t size) noexcept {
    return f && size==kRefBytes && f[0]=='E' && f[1]=='H' && f[2]=='R' && f[3]=='F';
}
inline bool valid_response(const uint8_t* expected, const uint8_t* actual, size_t size) noexcept {
    if(!valid_reference(actual,size) || !valid_reference(expected,size))return false;
    uint8_t diff=0;
    for(size_t i=0;i<kRefBytes;++i)diff|=expected[i]^actual[i];
    return diff==0;
}
} // namespace esphub
