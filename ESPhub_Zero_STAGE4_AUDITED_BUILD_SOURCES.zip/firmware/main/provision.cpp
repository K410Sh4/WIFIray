#include "provision.h"
#include "board.h"
#include <cstdio>
#include <cstring>
#include <cctype>
#include "esp_log.h"
#include "nvs.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char* TAG = "ehub.provision";

bool load_radio_credentials(RadioCredentials& out) {
    nvs_handle_t h;
    if (nvs_open("ehub-radio", NVS_READONLY, &h) != ESP_OK) return false;
    size_t ss = sizeof(out.ssid), pw = sizeof(out.password);
    const esp_err_t a = nvs_get_str(h, "ssid", out.ssid, &ss);
    const esp_err_t b = nvs_get_str(h, "pass", out.password, &pw);
    nvs_close(h);
    return a == ESP_OK && b == ESP_OK && ss > 1 && pw >= 17;
}

static bool safe_ssid(const char* s) {
    const size_t n = strlen(s);
    if (n < 1 || n > 32) return false;
    for (const char* p=s; *p; ++p) if (static_cast<unsigned char>(*p) < 33 || *p == '"') return false;
    return true;
}
static bool safe_password(const char* s) {
    const size_t n = strlen(s);
    if (n < 16 || n > 63) return false;
    for (const char* p=s; *p; ++p) if (static_cast<unsigned char>(*p) < 33 || *p == '"') return false;
    return true;
}
bool load_app_secret(uint8_t out[32]) {
    nvs_handle_t h;
    if(nvs_open("ehub-app",NVS_READONLY,&h)!=ESP_OK)return false;
    size_t size=32;
    const esp_err_t err=nvs_get_blob(h,"secret",out,&size);
    nvs_close(h);return err==ESP_OK && size==32;
}
static uint8_t hexDigit(char c) {
    if(c>='0'&&c<='9')return static_cast<uint8_t>(c-'0');
    if(c>='a'&&c<='f')return static_cast<uint8_t>(c-'a'+10);
    if(c>='A'&&c<='F')return static_cast<uint8_t>(c-'A'+10);
    return 255;
}
static bool save_app_secret(const char* hex) {
    if(strlen(hex)!=64)return false;
    uint8_t secret[32]{};
    for(size_t i=0;i<32;++i){
        const uint8_t hi=hexDigit(hex[i*2]),lo=hexDigit(hex[i*2+1]);
        if(hi>15||lo>15){memset(secret,0,sizeof(secret));return false;}
        secret[i]=static_cast<uint8_t>((hi<<4)|lo);
    }
    nvs_handle_t h;
    if(nvs_open("ehub-app",NVS_READWRITE,&h)!=ESP_OK){memset(secret,0,sizeof(secret));return false;}
    esp_err_t err=nvs_set_blob(h,"secret",secret,sizeof(secret));
    if(err==ESP_OK)err=nvs_commit(h);
    nvs_close(h);memset(secret,0,sizeof(secret));return err==ESP_OK;
}
static bool save(const char* ssid, const char* pass) {
    if (!safe_ssid(ssid) || !safe_password(pass)) return false;
    nvs_handle_t h;
    if (nvs_open("ehub-radio", NVS_READWRITE, &h) != ESP_OK) return false;
    esp_err_t err = nvs_set_str(h, "ssid", ssid);
    if (err == ESP_OK) err = nvs_set_str(h, "pass", pass);
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    return err == ESP_OK;
}

void physical_console_task(void*) {
    char line[160];
    ESP_LOGI(TAG, "USB provisioning: status, key-status, key <64hex>, ap-pass <16..63>, join <ssid> <16..63>, restart.");
    ESP_LOGW(TAG, "Use a trusted USB terminal; secrets may be echoed by its input mode. Never share terminal logs.");
    for (;;) {
        if (!fgets(line, sizeof(line), stdin)) {
            clearerr(stdin);
            vTaskDelay(pdMS_TO_TICKS(150));
            continue;
        }
        line[strcspn(line, "\r\n")] = '\0';
        if (!strcmp(line, "status")) {
            RadioCredentials saved{};
            if (load_radio_credentials(saved))
                ESP_LOGI(TAG, "Provisioned SSID=%s; password=REDACTED; role=%s", saved.ssid, kNodeName);
            else ESP_LOGW(TAG, "NOT PROVISIONED. Wi-Fi disabled.");
            memset(saved.password,0,sizeof(saved.password));
        } else if (!strcmp(line, "key-status")) {
            uint8_t secret[32]{};const bool configured=load_app_secret(secret);
            memset(secret,0,sizeof(secret));
            ESP_LOGI(TAG,"App key: %s",configured?"CONFIGURED":"NOT CONFIGURED");
        } else if (!strncmp(line,"key ",4)) {
            if(save_app_secret(line+4))ESP_LOGI(TAG,"App key stored; restart to revoke any previous session");
            else ESP_LOGE(TAG,"Invalid key. Provide exactly 64 hexadecimal characters");
        } else if (!strcmp(line, "restart")) {
            esp_restart();
        } else if (kIsCoordinator && !strncmp(line,"ap-pass ",8)) {
            const char* pass=line+8;
            if (!save("ESPHUB-ZERO",pass)) ESP_LOGE(TAG,"Invalid passphrase: require 16..63 printable non-space chars.");
            else ESP_LOGI(TAG,"AP credentials saved. Restart to apply. Password never logged.");
        } else if (!kIsCoordinator && !strncmp(line,"join ",5)) {
            char ssid[33]={}, pass[65]={};
            const int parsed=sscanf(line+5,"%32s %64s",ssid,pass);
            if (parsed!=2 || !save(ssid,pass)) ESP_LOGE(TAG,"Invalid input. join <ssid> <password> (16..63 non-space chars)");
            else ESP_LOGI(TAG,"STA credentials saved. Restart to apply. Password never logged.");
            memset(pass,0,sizeof(pass));
        } else {
            ESP_LOGW(TAG,"Unknown command or forbidden command for this board role.");
        }
        memset(line,0,sizeof(line));
    }
}
