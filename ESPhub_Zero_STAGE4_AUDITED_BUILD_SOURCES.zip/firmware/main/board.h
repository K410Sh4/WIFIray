#pragma once
#include "sdkconfig.h"

#if CONFIG_IDF_TARGET_ESP32S3
inline constexpr int kNodeId = 1;
inline constexpr const char* kNodeName = "S3 / REFERENCE AP";
inline constexpr bool kIsCoordinator = true;
#elif CONFIG_IDF_TARGET_ESP32C6
inline constexpr int kNodeId = 2;
inline constexpr const char* kNodeName = "C6 / CSI RECEIVER";
inline constexpr bool kIsCoordinator = false;
#elif CONFIG_IDF_TARGET_ESP32
inline constexpr int kNodeId = 3;
inline constexpr const char* kNodeName = "ESP32 / CSI RECEIVER";
inline constexpr bool kIsCoordinator = false;
#else
#error "Unsupported ESPhub hardware. Set ESP-IDF target to esp32s3, esp32c6 or esp32."
#endif
inline constexpr int kReferenceUdpPort = 42720;
inline constexpr int kReferencePps = 32; // fixed experimental starting rate, NOT measured maximum.
