#include "telemetry.h"
#include "freertos/FreeRTOS.h"
#include "freertos/portmacro.h"

static portMUX_TYPE s_guard=portMUX_INITIALIZER_UNLOCKED;
static RadioSnapshot s_last{};
void publish_radio_snapshot(const RadioSnapshot& snapshot) {
    portENTER_CRITICAL(&s_guard);
    s_last=snapshot;
    portEXIT_CRITICAL(&s_guard);
}
RadioSnapshot read_radio_snapshot() {
    portENTER_CRITICAL(&s_guard);
    const RadioSnapshot result=s_last;
    portEXIT_CRITICAL(&s_guard);
    return result;
}
