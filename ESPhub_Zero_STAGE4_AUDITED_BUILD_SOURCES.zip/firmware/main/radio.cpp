#include "radio.h"
#include "board.h"
#include "csi_worker.h"
#include "eh_reference.h"
#include <cerrno>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"

static constexpr const char* TAG="ehub.radio";
static EventGroupHandle_t s_wifi=nullptr;
static constexpr EventBits_t kHasIp=1;
static uint32_t s_reconnects=0;

bool radio_connected() {return s_wifi && (xEventGroupGetBits(s_wifi)&kHasIp)!=0;}

static void wifi_event(void*, esp_event_base_t base, int32_t id, void*) {
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        xEventGroupClearBits(s_wifi,kHasIp);
        if (s_reconnects < 1000000U) ++s_reconnects;
        // Backoff belongs to a dedicated task, not the Wi-Fi event callback.
    }
    if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        s_reconnects=0;
        xEventGroupSetBits(s_wifi,kHasIp);
        ESP_LOGI(TAG,"STA acquired IP; preparing CSI receiver");
    }
}

static void retry_task(void*) {
    while (true) {
        if (!radio_connected()) {
            uint32_t seconds=1+(s_reconnects>5?5:s_reconnects);
            vTaskDelay(pdMS_TO_TICKS(seconds*1000));
            if (!radio_connected()) {
                esp_err_t err=esp_wifi_connect();
                if(err!=ESP_OK) ESP_LOGW(TAG,"STA connect request: %s",esp_err_to_name(err));
            }
        } else vTaskDelay(pdMS_TO_TICKS(2000));
    }
}

void start_radio(const RadioCredentials& credentials) {
    s_wifi=xEventGroupCreate();
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    if (kIsCoordinator) esp_netif_create_default_wifi_ap();
    else esp_netif_create_default_wifi_sta();
    wifi_init_config_t init=WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&init));
    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    wifi_config_t config{};
    if (kIsCoordinator) {
        // Explicit WPA2, no open/hidden/unsecured fallback.
        strncpy(reinterpret_cast<char*>(config.ap.ssid),credentials.ssid,sizeof(config.ap.ssid));
        strncpy(reinterpret_cast<char*>(config.ap.password),credentials.password,sizeof(config.ap.password));
        config.ap.ssid_len=strlen(credentials.ssid);
        config.ap.channel=6; // RF validation must tune this before real deployments.
        config.ap.max_connection=3;
        config.ap.authmode=WIFI_AUTH_WPA2_PSK;
        config.ap.pmf_cfg.capable=true;
        config.ap.pmf_cfg.required=false; // ESP32 classic compatibility; document downgrade trade-off.
        ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
        ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP,&config));
        ESP_ERROR_CHECK(esp_wifi_start());
        xEventGroupSetBits(s_wifi,kHasIp);
        ESP_LOGI(TAG,"Reference AP started. SSID=%s. Password=REDACTED. Channel=6",credentials.ssid);
        xTaskCreate(reference_echo_task,"rf_echo",4096,nullptr,5,nullptr);
    } else {
        strncpy(reinterpret_cast<char*>(config.sta.ssid),credentials.ssid,sizeof(config.sta.ssid));
        strncpy(reinterpret_cast<char*>(config.sta.password),credentials.password,sizeof(config.sta.password));
        config.sta.threshold.authmode=WIFI_AUTH_WPA2_PSK;
        config.sta.pmf_cfg.capable=true;
        config.sta.pmf_cfg.required=false;
        ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT,WIFI_EVENT_STA_DISCONNECTED,&wifi_event,nullptr));
        ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT,IP_EVENT_STA_GOT_IP,&wifi_event,nullptr));
        ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
        ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA,&config));
        ESP_ERROR_CHECK(esp_wifi_start());
        ESP_ERROR_CHECK(esp_wifi_set_ps(WIFI_PS_NONE)); // prioritize sampling, measure power cost.
        xTaskCreate(retry_task,"wifi_retry",3072,nullptr,4,nullptr);
        xTaskCreate(reference_probe_task,"rf_probe",4096,nullptr,4,nullptr);
        xTaskCreate(csi_report_task,"rf_dsp",5120,nullptr,5,nullptr);
    }
}

void reference_echo_task(void*) {
    int fd=socket(AF_INET,SOCK_DGRAM,IPPROTO_IP);
    if(fd<0){ESP_LOGE(TAG,"Cannot create reference UDP socket");vTaskDelete(nullptr);}
    sockaddr_in listen{};listen.sin_family=AF_INET;
    listen.sin_addr.s_addr=htonl(INADDR_ANY);listen.sin_port=htons(kReferenceUdpPort);
    if(bind(fd,reinterpret_cast<sockaddr*>(&listen),sizeof(listen))!=0){close(fd);ESP_LOGE(TAG,"Cannot bind reference socket");vTaskDelete(nullptr);}
    uint8_t packet[esphub::kRefBytes];
    // 2 receivers x 32 packets/s; global cap prevents unlimited unicast echo.
    int64_t budget_window=esp_timer_get_time();
    uint32_t budget_used=0;
    for(;;){
        sockaddr_in peer{};socklen_t n=sizeof(peer);
        ssize_t got=recvfrom(fd,packet,sizeof(packet),0,reinterpret_cast<sockaddr*>(&peer),&n);
        if(!esphub::valid_reference(packet,got>0?static_cast<size_t>(got):0))continue;
        const int64_t now=esp_timer_get_time();
        if(now-budget_window>=1000000){budget_window=now;budget_used=0;}
        if(budget_used>=128U)continue;
        ++budget_used;
        // Unicast response: a reference Wi-Fi frame addressed to the receiver.
        // This is an RF stimulus, NOT authenticated user telemetry or a control API.
        (void)sendto(fd,packet,sizeof(packet),0,reinterpret_cast<sockaddr*>(&peer),n);
    }
}

void reference_probe_task(void*) {
    int fd=-1;uint32_t seq=0;
    esphub::RefPacket packet{};
    sockaddr_in ap{};ap.sin_family=AF_INET;ap.sin_port=htons(kReferenceUdpPort);
    inet_pton(AF_INET,"192.168.4.1",&ap.sin_addr);
    int64_t next=esp_timer_get_time();
    for(;;){
        if(!radio_connected()){
            if(fd>=0){close(fd);fd=-1;}
            vTaskDelay(pdMS_TO_TICKS(250));next=esp_timer_get_time();continue;
        }
        if(fd<0){
            fd=socket(AF_INET,SOCK_DGRAM,IPPROTO_IP);
            if(fd<0){vTaskDelay(pdMS_TO_TICKS(500));continue;}
            timeval timeout{};timeout.tv_sec=0;timeout.tv_usec=15000;
            setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
        }
        const uint64_t time_ms=static_cast<uint64_t>(esp_timer_get_time()/1000);
        packet=esphub::make_reference(seq++,time_ms);
        (void)sendto(fd,packet.data(),packet.size(),0,reinterpret_cast<sockaddr*>(&ap),sizeof(ap));
        // Datagram source + content are checked. No data here is accepted as a command.
        uint8_t response[128]{};
        sockaddr_in source{};socklen_t slen=sizeof(source);
        const ssize_t received=recvfrom(fd,response,sizeof(response),0,
            reinterpret_cast<sockaddr*>(&source),&slen);
        if(received>0 && (source.sin_addr.s_addr!=ap.sin_addr.s_addr ||
            source.sin_port!=ap.sin_port || !esphub::valid_response(
                packet.data(),response,static_cast<size_t>(received)))) {
            ESP_LOGW(TAG,"Untrusted RF reference response ignored");
        }
        next+=1000000/kReferencePps;
        int64_t wait=next-esp_timer_get_time();
        if(wait>0)vTaskDelay(pdMS_TO_TICKS(static_cast<uint32_t>(wait/1000)>0?wait/1000:1));
        else next=esp_timer_get_time();
    }
}
