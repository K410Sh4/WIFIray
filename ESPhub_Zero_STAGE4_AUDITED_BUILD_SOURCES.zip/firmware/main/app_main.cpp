#include "board.h"
#include "provision.h"
#include "radio.h"
#include "uplink.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

extern "C" void app_main(void) {
    const esp_err_t nvs=nvs_flash_init();
    if(nvs!=ESP_OK){
        // Never erase NVS automatically: secrets and provisioning would be destroyed.
        ESP_LOGE("ehub", "NVS init failed: %s. Keep flash backup and reprovision physically.",esp_err_to_name(nvs));
        return;
    }
    ESP_LOGI("ehub","ESPhub Zero radio milestone, node=%d role=%s",kNodeId,kNodeName);
    xTaskCreate(physical_console_task,"physical_usb",4096,nullptr,3,nullptr);
    RadioCredentials credentials{};
    if(!load_radio_credentials(credentials)){
        ESP_LOGW("ehub","No valid stored Wi-Fi settings. Radio OFF. Use trusted USB provisioning then restart.");
        return;
    }
    start_radio(credentials);
    xTaskCreate(authenticated_uplink_task,"auth_uplink",7168,nullptr,4,nullptr);
    // Do not retain an extra copy of the WPA2 password in the app task stack.
    volatile char* wipe=credentials.password;
    for (size_t i=0;i<sizeof(credentials.password);++i)wipe[i]=0;
}
