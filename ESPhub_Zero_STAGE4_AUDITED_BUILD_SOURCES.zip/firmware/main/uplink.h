#pragma once
void authenticated_uplink_task(void*);
