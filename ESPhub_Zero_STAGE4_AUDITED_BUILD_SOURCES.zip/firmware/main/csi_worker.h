#pragma once
#include <cstdint>
#include "esp_err.h"

esp_err_t start_csi_pipeline(); // called only after station has an AP BSSID
void csi_report_task(void* unused);
