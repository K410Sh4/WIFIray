#include "uplink.h"
#include "board.h"
#include "provision.h"
#include "radio.h"
#include "telemetry.h"
#include "eh_wire.h"
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "esp_log.h"
#include "esp_random.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "mbedtls/md.h"
#include "mbedtls/hkdf.h"
#include "mbedtls/gcm.h"

namespace {
constexpr char kTag[]="ehub.uplink";
constexpr uint8_t kMagic[5]={'E','H','U','B',1};
constexpr char kDeviceProof[]="EHUB-v1/DEVICE-PROOF";
constexpr char kClientProof[]="EHUB-v1/CLIENT-PROOF";
constexpr char kSession[]="EHUB-v1/SESSION/";
constexpr uint64_t kPendingUs=5000000ULL;
constexpr uint64_t kSessionUs=120000000ULL;
constexpr uint64_t kHelloRateUs=750000ULL;

void wipe(void* ptr,size_t n){volatile uint8_t* p=static_cast<volatile uint8_t*>(ptr);while(n--)*p++=0;}
uint64_t nowUs(){return static_cast<uint64_t>(esp_timer_get_time());}
bool samePeer(const sockaddr_in& a,const sockaddr_in& b){
    return a.sin_family==AF_INET&&b.sin_family==AF_INET&&a.sin_addr.s_addr==b.sin_addr.s_addr&&a.sin_port==b.sin_port;
}
bool mac(const uint8_t* key,size_t keySize,const uint8_t* input,size_t n,uint8_t out[32]){
    const auto* sha=mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
    return sha&&mbedtls_md_hmac(sha,key,keySize,input,n,out)==0;
}
bool proof(const uint8_t secret[32],const char* domain,const uint8_t client[16],const uint8_t device[16],uint8_t out[32]){
    uint8_t input[80]{};
    const size_t len=strlen(domain);
    if(len>46)return false;
    memcpy(input,domain,len);input[len]=static_cast<uint8_t>(kNodeId);
    memcpy(input+len+1,client,16);memcpy(input+len+17,device,16);
    const bool ok=mac(secret,32,input,len+33,out);
    wipe(input,sizeof(input));return ok;
}
bool equals(const uint8_t* a,const uint8_t* b,size_t n){
    uint8_t mismatch=0;for(size_t i=0;i<n;++i)mismatch|=a[i]^b[i];return mismatch==0;
}
struct Pending {
    bool valid=false;
    uint64_t at=0;
    sockaddr_in peer{};
    uint8_t client[16]{};
    uint8_t device[16]{};
};
struct Session {
    bool valid=false;
    uint64_t at=0;
    sockaddr_in peer{};
    uint8_t id[8]{};
    uint8_t deviceKey[32]{};
    uint32_t seq=0;
};
bool derive(const uint8_t secret[32],const Pending& p,Session& out){
    uint8_t salt[32]{};
    memcpy(salt,p.client,16);memcpy(salt+16,p.device,16);
    uint8_t info[32]{};
    constexpr size_t base=sizeof(kSession)-1;
    memcpy(info,kSession,base);info[base]=static_cast<uint8_t>(kNodeId);
    uint8_t derived[72]{};
    const auto* sha=mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
    const bool ok=sha&&mbedtls_hkdf(sha,salt,sizeof(salt),secret,32,info,base+1,derived,sizeof(derived))==0;
    if(ok){
        memcpy(out.id,derived,8);memcpy(out.deviceKey,derived+8,32);
        out.peer=p.peer;out.seq=0;out.at=nowUs();out.valid=true;
    }
    wipe(salt,sizeof(salt));wipe(info,sizeof(info));wipe(derived,sizeof(derived));
    return ok;
}
void clearPending(Pending& p){wipe(&p,sizeof(p));}
void clearSession(Session& s){wipe(&s,sizeof(s));}

bool sendTelemetry(int fd,Session& s){
    if(!s.valid||s.seq==UINT32_MAX)return false;
    RadioSnapshot snap=read_radio_snapshot();
    // No old observation may be presented as live after CSI is stopped or absent.
    if (!kIsCoordinator && (snap.uptime_ms == 0 ||
        nowUs()/1000 - snap.uptime_ms > 4000ULL)) {
        snap = RadioSnapshot{};
    }
    esphub::Telemetry t{};
    t.node=kNodeId;t.state=kIsCoordinator?5:snap.state;
    t.score=kIsCoordinator?0:snap.score;
    t.rssi=kIsCoordinator?-127:snap.rssi;
    t.carriers=kIsCoordinator?0:snap.carriers;
    t.accepted=kIsCoordinator?0:snap.accepted;
    t.rejected=kIsCoordinator?0:snap.rejected;
    t.queue_drops=kIsCoordinator?0:snap.queue_drops;
    t.baseline=kIsCoordinator?0:snap.baseline;
    t.uptime_ms=nowUs()/1000;
    uint8_t data[esphub::kTelemetryBytes]{};
    if(!esphub::encodeTelemetry(t,data,sizeof(data)))return false;
    uint8_t out[esphub::kFrameBytes]{};
    memcpy(out,kMagic,sizeof(kMagic));out[5]=0x20;out[6]=kNodeId;out[7]=0;
    memcpy(out+8,s.id,8);esphub::be32(out+16,s.seq);esphub::be64(out+20,t.uptime_ms);
    esphub::be16(out+28,esphub::kTelemetryBytes);
    uint8_t nonce[12]{};memcpy(nonce,s.id,8);esphub::be32(nonce+8,s.seq);
    mbedtls_gcm_context gcm;mbedtls_gcm_init(&gcm);
    int rc=mbedtls_gcm_setkey(&gcm,MBEDTLS_CIPHER_ID_AES,s.deviceKey,256);
    if(rc==0)rc=mbedtls_gcm_crypt_and_tag(&gcm,MBEDTLS_GCM_ENCRYPT,sizeof(data),nonce,sizeof(nonce),
        out,esphub::kHeaderBytes,data,out+esphub::kHeaderBytes,esphub::kTagBytes,
        out+esphub::kHeaderBytes+sizeof(data));
    mbedtls_gcm_free(&gcm);
    wipe(data,sizeof(data));wipe(nonce,sizeof(nonce));
    if(rc!=0){wipe(out,sizeof(out));return false;}
    // CRITICAL: consume the nonce after encryption even when UDP send fails.
    // Otherwise a new payload could be encrypted under the same AES-GCM key/nonce.
    ++s.seq;
    const ssize_t sent=sendto(fd,out,sizeof(out),0,reinterpret_cast<const sockaddr*>(&s.peer),sizeof(s.peer));
    wipe(out,sizeof(out));
    return sent==static_cast<ssize_t>(esphub::kFrameBytes);
}
} // namespace

void authenticated_uplink_task(void*){
    uint8_t secret[32]{};
    if(!load_app_secret(secret)){
        ESP_LOGW(kTag,"No application key. Encrypted Wi-Fi uplink OFF. Provision distinct key by trusted USB then restart.");
        vTaskDelete(nullptr);return;
    }
    Pending pending{};Session active{};
    uint64_t lastHello=0,lastSent=0;
    int fd=-1;
    for(;;){
        if(!radio_connected()){
            if(fd>=0){close(fd);fd=-1;}
            clearPending(pending);clearSession(active);
            vTaskDelay(pdMS_TO_TICKS(250));continue;
        }
        if(fd<0){
            fd=socket(AF_INET,SOCK_DGRAM,IPPROTO_IP);
            if(fd<0){vTaskDelay(pdMS_TO_TICKS(500));continue;}
            timeval timeout{};timeout.tv_sec=0;timeout.tv_usec=200000;
            setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
            sockaddr_in local{};local.sin_family=AF_INET;local.sin_addr.s_addr=htonl(INADDR_ANY);
            local.sin_port=htons(esphub::kUplinkPort);
            if(bind(fd,reinterpret_cast<sockaddr*>(&local),sizeof(local))!=0){
                ESP_LOGE(kTag,"Telemetry UDP bind failed");close(fd);fd=-1;
                vTaskDelay(pdMS_TO_TICKS(800));continue;
            }
            ESP_LOGI(kTag,"Authenticated Wi-Fi telemetry listening; no unauthenticated observations emitted");
        }
        const uint64_t now=nowUs();
        if(pending.valid && now-pending.at>kPendingUs)clearPending(pending);
        if(active.valid && now-active.at>kSessionUs)clearSession(active);
        uint8_t in[128]{};sockaddr_in peer{};socklen_t peerLen=sizeof(peer);
        const ssize_t n=recvfrom(fd,in,sizeof(in),0,reinterpret_cast<sockaddr*>(&peer),&peerLen);
        if(n>0 && peerLen==sizeof(peer) && peer.sin_family==AF_INET){
            if(esphub::validHello(in,static_cast<size_t>(n),kNodeId)){
                if(lastHello==0 || now-lastHello>=kHelloRateUs){
                    lastHello=now;
                    clearPending(pending);pending.valid=true;pending.at=now;pending.peer=peer;
                    memcpy(pending.client,in+7,16);esp_fill_random(pending.device,16);
                    uint8_t out[esphub::kChallengeBytes]{};memcpy(out,kMagic,5);out[5]=2;out[6]=kNodeId;
                    memcpy(out+7,pending.client,16);memcpy(out+23,pending.device,16);
                    if(proof(secret,kDeviceProof,pending.client,pending.device,out+39))
                        (void)sendto(fd,out,sizeof(out),0,reinterpret_cast<sockaddr*>(&peer),sizeof(peer));
                    else clearPending(pending);
                    wipe(out,sizeof(out));
                }
            }else if(esphub::validProof(in,static_cast<size_t>(n),kNodeId)&&
                pending.valid&&now-pending.at<=kPendingUs&&samePeer(peer,pending.peer)){
                uint8_t expected[32]{};
                const bool authenticated=proof(secret,kClientProof,pending.client,pending.device,expected)
                    &&equals(in+7,expected,sizeof(expected));
                wipe(expected,sizeof(expected));
                if(authenticated){
                    Session newSession{};
                    if(derive(secret,pending,newSession)){
                        clearSession(active);active=newSession;
                        wipe(&newSession,sizeof(newSession));
                        lastSent=0;ESP_LOGI(kTag,"Fresh authenticated session for node %d",kNodeId);
                    }
                } // Failed authentication is never logged with identifying data.
                clearPending(pending);
            }
        }
        wipe(in,sizeof(in));
        const uint64_t after=nowUs();
        if(active.valid && (lastSent==0||after-lastSent>=1000000ULL)){
            if(!sendTelemetry(fd,active))ESP_LOGW(kTag,"Encrypted telemetry send failure");
            if(active.seq==UINT32_MAX)clearSession(active);
            lastSent=after;
        }
    }
}
