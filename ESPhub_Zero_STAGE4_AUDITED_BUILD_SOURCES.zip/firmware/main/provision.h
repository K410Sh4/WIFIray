#pragma once
#include <cstddef>
#include <cstdint>

struct RadioCredentials {
    char ssid[33] = {};
    char password[65] = {};
};

// NVS credentials are NOT encrypted at rest unless ESP flash encryption is enabled.
bool load_radio_credentials(RadioCredentials& out);
bool load_app_secret(uint8_t out[32]);
void physical_console_task(void* unused);
