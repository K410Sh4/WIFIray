#pragma once
#include <cstdint>
#include "provision.h"

void start_radio(const RadioCredentials& credentials);
bool radio_connected();
void reference_echo_task(void* unused);
void reference_probe_task(void* unused);
