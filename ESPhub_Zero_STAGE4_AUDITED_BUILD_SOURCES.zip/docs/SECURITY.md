# Segurança — Marco 3 (teste host, não auditado)

**Positivo no código:** criptografia do transporte de telemetria com HMAC-SHA256, HKDF e AES-256-GCM; segredos distintos por nó; rejeição de replay e tag inválida sem derrubar a recepção; rotação de sessão; distinção entre telemetria válida, faltante e antiga; CLI USB evita eco no terminal local e não guarda senha da rede; Android nunca persiste as chaves digitadas.

**Limitações claras:** `key <64hex>` e a senha Wi-Fi percorrem a interface USB em texto claro (um hospedeiro ou cabo não confiável pode interceptá-los). O MCU, drivers ou ferramentas externas podem ecoar dados: o CLI não consegue garantir o comportamento do firmware/terminal. Arquivos locais `0600` ainda têm segredo em texto claro; use diretório e backup protegidos. NVS do firmware continua sem garantia de criptografia em repouso. Não alegar que o apagamento de chaves do heap JVM é absoluto. O teste host não configura Secure Boot, eFuses, Flash Encryption ou atualização OTA assinada.

**Mudanças no rádio e no app exigem teste de reautenticação, troca de rede, flood, reboot e verificação de sessão.** Wi-Fi RF não identifica humanos por si só; não usar como controle de acesso, alarme ou segurança física.
