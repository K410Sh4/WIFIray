# Marco 3 — alcance, implementação e critérios de aceitação

## Implementado

- `android/core/.../AuthenticatedTelemetryGate.kt`: encapsula validação AEAD, versão, nó e parser; `ReplayException` e `AuthenticationException` são capturadas no gate, sem interromper recepção UDP. Quadros inválidos não avançam a indicação de frescor nem geram visualização.
- `SecureWire.Message.sequence`: sequência autenticada exposta **após** tag GCM validada; chaves derivadas são zeradas por `Channel.destroy()` no melhor esforço do heap JVM quando sessão é substituída ou encerrada. Strings JVM/KeyStore internos não oferecem garantia de apagamento completo.
- `LinkHealth`: frames válidos, saltos de sequência, replay e tags inválidas com janela por sessão. Lacunas representam `seq_n - seq_(n-1) - 1`; **não equivalem necessariamente a perda Wi-Fi**, pois o emissor consome nonces após cifrar mesmo se `sendto()` falhar.
- `WifiRadarClient`: chaves devem ser 3 distintas, limpeza de sessões ao reconectar, descarte de respostas malformadas sem encerrar thread; `MainActivity` evita vincular o processo a uma rede diferente de 192.168.4.x e lida com thread encerrada.
- `tools/provision_usb.py`: coleta senha via `getpass`, gera segredo aleatório de 32 bytes por nó, envia comandos exclusivamente via USB serial, aguarda confirmação de Wi-Fi/chave, cria arquivo novo somente com segredo do nó e permissão 0600 sem substituir arquivos anteriores. Não imprime credenciais. O arquivo é plaintext; não o confunda com cofre criptografado.

## Testes host concluídos

- C++ RadarCore, referência RF e formato wire executados com ASan+UBSan.
- Python: contrato de protocolo + USB simulado (incluindo timeouts e symlink refusal).
- Kotlin/JVM: prova/AEAD, parser, regressão de replay, gaps, descarte de sessão e gate seguro.

## Pendente para aprovação de produto

1. Compilar `idf.py` com SDK, target, partições e flash exatos das 3 placas; compilar APK com Android SDK 35 e assinar builds de release.
2. Teste físico do USB (incluindo UART echo do terminal/firmware), conexão do AP e política do Android para redes sem internet, recuperação de falhas, latência, memória, temperatura e estabilidade de 24h.
3. Secure Boot V2/Flash Encryption/NVS encryption **quando suportados por cada variante**, com procedimento de provisionamento e recuperação seguro; nunca habilitar eFuses irreversíveis sem validação física, backup e aprovação do operador.
4. Verificar canal RF, taxas CSI, falsos positivos, imóvel/animais e benchmark com protocolos rastreáveis; sem isso não divulgar detecção humana confiável.
5. Auditoria independente de segurança, testes de fuzzing de datagramas, disponibilidade frente a flood, ameaça de USB físico, OTA assinada/rollback.

**Este é código-fonte experimental; não é certificação, release nem 1 APK + 3 BINs.**

### Política de privacidade do app

O cliente é encerrado em `Activity.onStop()` (sem coleta em background neste marco); callbacks de rede enfileirados antes de parar são descartados por epoch de sessão. Seleção de Wi-Fi 192.168.4.x restringe rota acidental, mas não comprova a identidade do SSID: a prova criptográfica por nó continua obrigatória.
