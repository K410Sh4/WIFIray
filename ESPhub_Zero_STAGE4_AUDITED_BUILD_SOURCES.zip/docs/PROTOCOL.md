# ESPhub Wire v1 — contrato do protótipo (telemetria do Marco 2)

Todos os campos multibyte em **big-endian**. UDP referência (RF) porta **42720**; UDP aplicativo autenticação/telemetria porta **42722**. Os nós aceitam HELLO apenas destinado à identidade correta; prova HMAC deve vir do mesmo IP e porta e antes de expirar o desafio (5 s). Apenas uma sessão autenticada ativa por nó; HELLO sozinho não revoga sessão anterior.

| Mensagem | Bytes | Estrutura |
|---|---:|---|
| HELLO | 23 | `EHUB`, versão1, tipo `01`, nó, nonceCliente16 |
| CHALLENGE | 71 | `EHUB`, versão1, tipo `02`, nó, nonceCliente16, nonceDispositivo16, HMAC32 |
| PROOF | 39 | `EHUB`, versão1, tipo `03`, nó, HMAC32 |
| TELEMETRY | 78 | Cabeçalho30, ciphertext32, tagGCM16 |

Proof dispositivo: HMAC-SHA256(segredoNó, `EHUB-v1/DEVICE-PROOF || node || nonceCliente || nonceDispositivo`). Proof cliente substitui domínio por `EHUB-v1/CLIENT-PROOF`. HKDF-SHA256(segredoNó, salt = nonces concatenados, info = `EHUB-v1/SESSION/ || node`, output 72 bytes): ID8, device-to-app32, app-to-device32. Comparação HMAC em tempo constante; sem dados antes de ambas as provas.

Cabeçalho AES: `EHUB`4, versão1, kind1 (`0x20`), node1, flags1 (`0`), sessionID8, sequência4, tempo monotônico8, comprimento2 = total30. AAD=30 bytes exatos. NonceGCM12 = sessionID8 + sequência4; tag16. Sessão nova após reboot, expiração ou antes do overflow; sequência é consumida após cifrar, **inclusive se envio UDP falhar**. Contador recebido avança apenas após autenticação da tag.

Payload telemetry v1 (32 bytes): offset0 versão1, 1 nó1, 2 state1, 3 score1, 4 RSSI signed8, 5 reservado0, 6 carriersU16, 8 acceptedU32, 12 rejectedU32, 16 queueDropsU32, 20 baselineU32, 24 uptimeMsU64. Estado `0 NoData`, `1 Calibrating`, `2 Quiet`, `3 Changed`, `4 Degraded`, `5 ReferenceOnly`. O estado 5 pertence ao S3; nunca é classificado como ocupação. Score não mede confiança humana.

**NÃO IMPLEMENTADO:** envio de CSI bruto, controles remotos, descoberta alternativa se broadcast não funcionar, OTA, negociação multiusuário e testes físicos.
