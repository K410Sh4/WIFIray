# ESPhub Zero — Marco 2: autenticação UDP Wi-Fi + Android

## O que foi implementado no fonte

- S3, C6 e DevKit escutam **UDP 42722**; os ESPs mantêm funções RF anteriores em 42720.
- O Android conecta **manualmente** ao AP do S3 (`ESPHUB-ZERO`, IP S3 192.168.4.1). O app força o processo à rede Wi-Fi escolhida, pois Android pode preferir dados móveis numa rede sem internet.
- C6/DevKit capturam CSI no callback, copiam em fila limitada; `csi_report_task` processa na tarefa de DSP, publica snapshot 1 Hz sem dados brutos.
- S3 transmite referência e reporta `ReferenceOnly=5`, **não** detecta pessoas.
- Android envia descoberta por broadcast local `192.168.4.255`, e ao S3 por unicast `192.168.4.1`. Cada nó responde com prova HMAC e nonce próprio. O Android verifica prova de dispositivo e responde prova de cliente. Só depois o firmware cria nova sessão.
- HKDF-SHA256 estabelece ID de sessão e chave AES-256-GCM independente por direção. O firmware envia somente telemetria autenticada, nunca KPI em texto simples por Wi-Fi. A telemetria tem 32 bytes e é cifrada com cabeçalho completo como AAD.
- Android só atualiza UI após validar GCM, ID do nó, ID de sessão, origem de IP, estado/range e sequência estritamente crescente; cada leitura expira após 5 s sem atualização.
- O nonce GCM é `sessionId(8)||seq(4)`. **O firmware consome o número de sequência depois de cifrar mesmo se o envio UDP falhar**, impedindo reutilização de nonce quando tentar enviar dados novos. A sessão expira a cada 120 s; Android tenta renovar preventivamente após 90 s.
- Chaves de aplicação exclusivas e aleatórias por nó devem ser provisionadas por USB via `key <64hex>`; não há PSK de aplicação fixo no código. O APK **não salva** as chaves; os campos são apagados ao iniciar/parar e a janela impede screenshots. Android e firmware preservam a senha Wi-Fi em mecanismos diferentes: Android usa a rede Wi-Fi do sistema, firmware usa NVS (não pressupor criptografia em repouso).

## Configuração inicial no laboratório

1. Gere **quatro segredos** separados num computador confiável: uma senha AP de 16–63 caracteres, mais três chaves aleatórias de 32 bytes (64 hex cada). Exemplo: `python -c "import secrets; print(secrets.token_hex(32))"` **três vezes**. Não publique logs, prints nem esse material em GitHub.
2. No S3, console USB: `ap-pass SUA_SENHA_AP`, `key CHAVE_S3`, `restart`.
3. No C6: `join ESPHUB-ZERO SUA_SENHA_AP`, `key CHAVE_C6`, `restart`.
4. No DevKit: `join ESPHUB-ZERO SUA_SENHA_AP`, `key CHAVE_DEVKIT`, `restart`.
5. No Android, conecte via Configurações de Wi-Fi ao `ESPHUB-ZERO`; habilite “permanecer conectado” se o sistema avisar que não tem internet. Abra o APK **depois** de conectar à rede e insira as três chaves distintas. Inicie o canal autenticado.
6. Posicione os nós de forma estável e deixe o cômodo vazio durante calibração. Observe índices de RF, pacotes e o aviso de leitura obsoleta. **Jamais interprete o escore como porcentagem de pessoas.**

## Problemas de integração a verificar no hardware

- Broadcast do AP para as STAs pode ser bloqueado ou atrasado por firmware, economia de energia do telefone ou regras do Android. Não foi testado fisicamente; se não houver desafio dos nós 2/3, adicionar diretório de nós autenticado no S3, sem improvisar IPs fixos e assumir que funcionou.
- O eco de referência no S3 está limitado globalmente a 128 respostas/s para limitar flood local. O S3 suporta no máximo 3 clientes configurados: C6, DevKit e telefone. Sem múltiplos celulares simultâneos nesta configuração.
- A cobertura e a qualidade do CSI variam com antenas e ambiente; cabe medir filas, escore, latência, CPU, RAM, perdas, corrente e reconexão; nem a pontuação nem as linhas desenhadas representam geometria real.
- Validar as APIs específicas ESP-IDF 5.5.1 nas três placas. Nesta etapa não foi feita compilação ESP-IDF nem Gradle Android, nem teste físico.
- Console USB pode ecoar o texto que você digita. Desative o eco do terminal ou use provisionamento físico com entrada mascarada na futura revisão; não cole logs.
- Chaves em NVS NÃO estão protegidas de extração de flash sem Flash Encryption/secure boot devidamente habilitados e validados por placa. Não instalar em produção até esse requisito ser tratado.

## Testes de aceitação antes de declarar o recurso concluído

- Medida de RF intacta com celular ausente; Wi-Fi AP e 2 STA conectados.
- Dispositivo sem chave => nenhum datagrama de medida enviado.
- Chave errada => não autentica, nenhum pacote descriptografado.
- Repetição e reordenação de sequência => descarta sem avançar estado.
- Pacote com flag/tamanho/AAD/tag adulterado => descarta sem alterar UI.
- Perda de 20% dos pacotes e reinicialização/reconexão de um nó => leitura expira; nova sessão necessária.
- Taxa e latência sob espectro ocupado, calibração vazia e ocupada, múltiplas pessoas, pessoa parada, animais, portas, com relatório de falsos positivos/negativos.
- 1 h de soak, heap mínimo, temperatura e consumo; verificar limites específicos de C6, S3 N16R8 e DevKit.
