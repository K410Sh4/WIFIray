# Estado verificável — Marco 4, candidata de build

| Área | Evidência e estado |
|---|---|
| Detector CSI/serialização/protocolo | Testes host C++/Python/Kotlin executados; não há teste de chip |
| Radio Wi-Fi S3, C6 e DevKit | Fonte existente, compilação ESP-IDF ainda pendente |
| Campo CSI do ESP32-C6 | `acquire_csi_he_stbc`: conferido com a definição documentada para C6; NÃO alegar compilação |
| Compilação sem SDK herdado | `build-stage4.yml` configura alvo explícito e `sdkconfig.defaults.<target>` |
| Flash/partição alvo | CSV 4MB para C6/DevKit, 16MB para S3, sem OTA; assume variante e requer conferência física |
| FULL.bin | Build `idf.py merge-bin` e auditor de chip/flash/offset implementados, execução pendente |
| APK | Workflow `assembleDebug` implementado, execução pendente |
| Pacote de quatro binários | Publicação bloqueada até testes + 3 firmwares + APK passarem |
| Wi-Fi HMAC/HKDF/AES-GCM | Modelo e fonte existentes; testes host, não pentest de campo |
| Chaves criptografadas em NVS; Secure Boot/eFuses | PENDENTE, proibido declarar produção |
| Teste RF/bateria/PSRAM/desempenho/24 h | PENDENTE |
| Pessoas/localização | Não implementado, não inferível apenas do diagrama de RF |

O código não foi enviado para `classfeedback` nem para branches de versões antigas. Novo repositório vazio ainda não disponível.
