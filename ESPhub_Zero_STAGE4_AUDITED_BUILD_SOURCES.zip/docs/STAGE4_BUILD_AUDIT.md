# Marco 4 — auditoria antes do build (2026-09-19)

**Situação:** implementação de build reproduzível preparada, host tests executáveis, build nativo ESP-IDF/Android SDK NÃO executado neste ambiente. Sem APK/BIN entregues ou prova física. Não é release.

Bloqueadores identificados e tratados: perfis alvo 4/16 MB explícitos; CSV de partições fábrica para apps maiores que default e sem OTA; resposta CSI e estado antigo zerados em desconexão; estado CSI também expira antes do envio; relógio de recepção Android verificado APÓS o datagrama; flags reservadas rejeitadas; checagem de alvos, offsets e tamanho máximo de flash em FULL.bin; teste negativo do verificador.

Bloqueadores residuais para aprovação: ESP-IDF v5.5.1 em ambiente real, Android Gradle/SDK 35, compatibilidade das APIs C6 sob compilador, identificação física de flash/PSRAM do S3 e módulos C6/DevKit, compatibilidade de bootloader e USB, runtime Wi-Fi/CSI/criptografia medido e eFuses de segurança físicos. Não habilitar Secure Boot/Flash Encryption irreversivelmente sem projeto de recuperação e anuência expressa.

**Atenção:** partições single-factory sem OTA. Gravando `FULL.bin` em 0x0 apaga/reescreve parte do NVS anterior se flashear com `erase_flash`; faça backup das credenciais antes de migrar. Chaves ficam em NVS sem garantia de confidencialidade física. O app é debug-assinado até release com chave privada do operador.

O build valida apenas sintaxe e integração SDK; não comprova detecção de pessoas, estabilidade física ou imunidade a interferências. Um único `.bin` FULL é produzido por chip com `idf.py merge-bin` e verificado por `ci/verify_firmware.py`.

## Pente-fino adicional

- **C6 CSI:** o campo do arquivo-fonte é `acquire_csi_he_stbc`, compatível com a definição C6 documentada. A suspeita inicial de incompatibilidade não se confirmou na leitura do fonte; a compilação com o ESP-IDF ainda é requisito para aprovar a API. Não fazer alteração artificial.
- **Android:** o tempo de um desafio e da telemetria agora é calculado *após* `receive()`. Flags reservadas e timestamps negativos são rejeitados antes da aceitação; regressão JVM incluída.
- **CSI obsoleto:** ao perder Wi-Fi/reconectar, zera o snapshot e a linha-base. O uplink publica NoData em vez de reaproveitar uma medição com mais de 4 s.
- **Firmwares:** imagens brutas merged; `ci/verify_firmware.py` verifica perfil alvo, partições, offset do cabeçalho ESP e tamanho <= capacidade declarada. Testes negativos com imagens sintéticas são apenas testes do verificador, não builds físicos.
- **Qualidade:** a suíte local C++/Python/Kotlin deve passar; workflow completo para SDK é o portão que falta, não um resultado atual.
- **Credenciais:** a persistência atual em NVS não é confidencial contra acesso físico. Arquivos de chave em texto claro locais não entram no ZIP. O provisioning USB ainda admite eco pelo host/driver.
