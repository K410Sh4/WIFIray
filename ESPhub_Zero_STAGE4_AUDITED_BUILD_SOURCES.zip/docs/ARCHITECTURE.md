# ESPhub Zero — arquitetura do código atual (candidata de laboratório)

## Responsabilidades

| Componente | Responsabilidade atual | Limite |
|---|---|---|
| S3 N16R8 | AP WPA2, referência UDP unicast e sessão autenticada do cliente | Não faz reconstrução de pessoa; teste de flash/PSRAM ainda pendente |
| C6 | Cliente Wi-Fi, CSI passivo do AP, DSP independente e telemetria cifrada | Outros rádios do C6 não são prometidos simultaneamente |
| ESP32 DevKit V1 | Segundo enlace CSI com DSP independente e telemetria cifrada | Flash/módulo exatos devem ser confirmados |
| Android | Entrada efêmera de três segredos, autenticação por nó, UDP Wi-Fi, estado stale, desenho de dois enlaces | Não persiste chaves; não faz imagem corporal nem ML |

Dois fluxos separados: datagramas de referência UDP/42720 não autorizam comandos e apenas estimulam medição RF; UDP/42722 é canal autenticado de aplicação com HANDSHAKE e AES-256-GCM. O callback CSI copia bytes para uma fila limitada; DSP e telemetria executam fora do callback. Snapshots são copiados em região crítica curta.

## Alvos e riscos operacionais

A configuração de partida é 32 pacotes de referência/s por receptor, 1 relatório/s e AP canal6; são valores *não otimizados*, não capacidade máxima medida. Os dois receptores e um telefone ocupam os 3 clientes do AP. Android deve se manter conectado a uma rede sem internet. A descoberta via broadcast pode exigir fallback testado; tal fallback ainda não existe.

A superfície de ataque inclui console físico de provisionamento, NVS, AP, UDP e aplicativo Android. Segurança do protocolo de sessão não substitui Secure Boot, Flash Encryption, testes anti-DoS ou OTA assinada; não são entregues aqui.

## Critérios para próximo marco

Compilação real com ESP-IDF 5.5.1 e Android SDK35; integração em hardware com prova HMAC e tag GCM correta, falsos positivos/negativos, perda/stale, reset/rekey, taxa e coabitação. Só então ampliar as ferramentas ao que hardware e métricas sustentarem.
