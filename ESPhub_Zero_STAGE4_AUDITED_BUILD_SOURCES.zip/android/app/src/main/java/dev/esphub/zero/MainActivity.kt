package dev.esphub.zero

import android.app.Activity
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.InputType
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color

class MainActivity:Activity(){
    private val handler=Handler(Looper.getMainLooper())
    private val fields=mutableMapOf<Int,EditText>()
    private val cards=mutableMapOf<Int,TextView>()
    private val readings=mutableMapOf<Int,Pair<WireTelemetry,Long>>()
    private val states=mutableMapOf<Int,String>()
    private var client:WifiRadarClient?=null
    private var sessionEpoch=0L // invalidate callbacks queued before Stop/restart
    private lateinit var map:RadarView
    private lateinit var message:TextView
    private lateinit var networking:ConnectivityManager
    private val refresher=object:Runnable{
        override fun run(){render();handler.postDelayed(this,500L)}
    }
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE)
        networking=getSystemService(ConnectivityManager::class.java)
        val density=resources.displayMetrics.density
        fun px(n:Int)=(density*n).toInt()
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(px(18),px(18),px(18),px(18))}
        fun note(s:String,large:Boolean=false):TextView=TextView(this).also{
            it.text=s;it.textSize=if(large)21f else 14f;it.setTextColor(Color.rgb(22,32,45));
            it.setPadding(0,px(8),0,px(8));root.addView(it)
        }
        note("ESPhub Zero • radar experimental",true)
        note("O celular deve estar conectado ao AP ESPHUB-ZERO do S3. Wi-Fi transporta as medições; Bluetooth não é usado nesta etapa.")
        note("Conecte o celular ao Wi-Fi antes de iniciar. Configure senhas Wi-Fi e 3 chaves de aplicação distintas por USB.")
        Button(this).also { it.text="ABRIR CONFIGURAÇÕES WI-FI";root.addView(it);it.setOnClickListener{
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
        }}
        for(id in 1..3){
            val name=when(id){1->"S3 • coordenador";2->"C6 • receptor";else->"DevKit • receptor"}
            note("Chave de aplicação $name (64 caracteres hexadecimais)")
            val key=EditText(this).apply{
                hint="Somente em memória; não é salva"
                inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                isSingleLine=true
                maxLines=1
            }
            fields[id]=key;root.addView(key)
        }
        message=note("Pronto para iniciar.")
        Button(this).also{it.text="INICIAR CANAL WI-FI AUTENTICADO";root.addView(it);it.setOnClickListener{start()}}
        Button(this).also{it.text="PARAR / DESCARTAR CHAVES";root.addView(it);it.setOnClickListener{stopClient()}}
        map=RadarView(this);root.addView(map,LinearLayout.LayoutParams(-1,px(235)))
        note("As linhas mostram perturbações de RF e só aparecem quando há telemetria autenticada e recente.")
        for(id in 1..3){cards[id]=note("Nó $id: aguardando autenticação")}
        setContentView(ScrollView(this).apply{addView(root)})
        handler.post(refresher)
    }
    private fun decodeHex(s:String):ByteArray?{
        if(s.length!=64)return null
        val a=ByteArray(32)
        for(i in 0..31){
            val hi=Character.digit(s[i*2],16);val lo=Character.digit(s[i*2+1],16)
            if(hi<0||lo<0){a.fill(0);return null};a[i]=((hi shl 4) or lo).toByte()
        }
        return a
    }
    private fun start(){
        if(client!=null && client?.isRunning()!=true) stopClient()
        if(client!=null){message.text="Já iniciado. Pare antes de iniciar novamente.";return}
        // Do not bind to an unrelated Wi-Fi network or route to mobile data.
        val wifi=networking.allNetworks.firstOrNull { network ->
            networking.getNetworkCapabilities(network)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)==true &&
            networking.getLinkProperties(network)?.linkAddresses?.any { link ->
                val host=link.address.hostAddress.orEmpty()
                host.startsWith("192.168.4.") && host!="192.168.4.1"
            }==true
        }
        if(wifi==null){message.text="Conecte ao Wi-Fi do S3 (rede 192.168.4.x); não selecione outra rede.";return}
        val secrets=mutableMapOf<Int,ByteArray>()
        for(id in 1..3){
            val key=decodeHex(fields[id]?.text.toString().trim())
            if(key==null){message.text="Chave do nó $id inválida: 64 dígitos hex.";secrets.values.forEach{it.fill(0)};return}
            secrets[id]=key
        }
        if(secrets.values.map {it.toList()}.toSet().size!=3){
            message.text="Cada placa precisa de uma chave exclusiva; chaves repetidas são rejeitadas."
            secrets.values.forEach{it.fill(0)};return
        }
        // Binding to a selected Wi-Fi network prevents accidental cellular routing on no-internet APs.
        if(!networking.bindProcessToNetwork(wifi)){
            message.text="Não foi possível vincular o processo ao Wi-Fi.";secrets.values.forEach{it.fill(0)};return
        }
        val epoch=++sessionEpoch
        val candidate=WifiRadarClient{node,report,status->runOnUiThread {
            if(sessionEpoch!=epoch) return@runOnUiThread
            if(node in 1..3){states[node]=status;if(report!=null)readings[node]=report to SystemClock.elapsedRealtime()}
            else message.text=status
        }}
        try{candidate.start(secrets);client=candidate
            fields.values.forEach {it.setText("");it.isEnabled=false}
            message.text="Wi-Fi em uso. Buscando nós com desafio HMAC; nenhum dado antes de autenticar."
        }catch(e:Exception){networking.bindProcessToNetwork(null);message.text="Falha ao iniciar: ${e.javaClass.simpleName}"}
        finally{secrets.values.forEach{it.fill(0)}}
    }
    private fun render(){
        val now=SystemClock.elapsedRealtime()
        for(id in 1..3){
            val item=readings[id]
            cards[id]?.text=if(item==null || now-item.second>5000){
                "Nó $id: sem telemetria autenticada recente • ${states[id] ?: "aguardando"}"
            }else{
                val t=item.first
                "Nó $id • ${t.stateLabel()} • alteração ${t.score}/100 • RSSI ${t.rssi} dBm\n"+
                "CSI aceitos ${t.accepted} • rejeitados ${t.rejected} • fila ${t.queueDrops} • calibração ${t.baseline}"
            }
        }
        map.setReadings(readings.filterValues {now-it.second<=5000})
    }
    private fun stopClient(){
        sessionEpoch++
        client?.stop();client=null;networking.bindProcessToNetwork(null)
        fields.values.forEach {it.isEnabled=true;it.setText("")}
        readings.clear();states.clear();message.text="Interrompido. Digite novamente as três chaves antes de iniciar."
        render()
    }
    override fun onStop(){
        // Do not keep the radio receiver active when the application leaves foreground.
        if(client!=null) stopClient()
        super.onStop()
    }
    override fun onDestroy(){handler.removeCallbacks(refresher);stopClient();super.onDestroy()}
}
