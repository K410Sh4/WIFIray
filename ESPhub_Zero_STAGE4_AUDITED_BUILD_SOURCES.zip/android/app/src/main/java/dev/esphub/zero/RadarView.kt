package dev.esphub.zero

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.View

/** Link activity diagram: deliberate avoidance of fake human position or body silhouette. */
class RadarView(context:Context):View(context) {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    private var readings:Map<Int,Pair<WireTelemetry,Long>> = emptyMap()
    fun setReadings(value:Map<Int,Pair<WireTelemetry,Long>>){readings=value;invalidate()}
    override fun onDraw(canvas:Canvas){
        super.onDraw(canvas)
        val w=width.toFloat();val h=height.toFloat();if(w<=0f||h<=0f)return
        val sx=w*.5f;val sy=h*.17f;val x2=w*.2f;val x3=w*.8f;val ry=h*.70f
        fun line(node:Int,x:Float){
            val reading=readings[node]
            val fresh=reading!=null&&SystemClock.elapsedRealtime()-reading.second<5000
            val score=if(fresh)reading!!.first.score else 0
            paint.color=when{
                !fresh->Color.rgb(100,116,139)
                reading!!.first.state==3->Color.rgb(249,115,22)
                reading.first.state==2->Color.rgb(34,197,94)
                else->Color.rgb(148,163,184)
            }
            paint.style=Paint.Style.STROKE
            paint.strokeWidth=(2f+score/100f*9f)*resources.displayMetrics.density
            canvas.drawLine(sx,sy,x,ry,paint)
            paint.style=Paint.Style.FILL
            paint.color=Color.DKGRAY
            paint.textSize=12f*resources.displayMetrics.scaledDensity
            canvas.drawText(if(fresh)"$score/100 • RF" else "Sem dados",x-24f,ry-30f,paint)
        }
        line(2,x2);line(3,x3)
        paint.color=Color.rgb(37,99,235)
        val radius=7f*resources.displayMetrics.density
        for((x,y) in listOf(sx to sy,x2 to ry,x3 to ry))canvas.drawCircle(x,y,radius,paint)
        paint.textSize=12f*resources.displayMetrics.scaledDensity
        paint.color=Color.DKGRAY
        canvas.drawText("S3 • referência",sx-48f,sy-18f,paint)
        canvas.drawText("C6",x2-12f,ry+27f,paint)
        canvas.drawText("DevKit",x3-23f,ry+27f,paint)
        paint.textSize=11f*resources.displayMetrics.scaledDensity
        canvas.drawText("Visualização dos enlaces; não é localização corporal",15f,h-14f,paint)
    }
}
