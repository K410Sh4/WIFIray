package dev.esphub.zero

import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketException
import java.net.SocketTimeoutException
import java.security.SecureRandom
import java.util.concurrent.atomic.AtomicBoolean

/** All networking occurs off the main thread. No telemetry accepted before mutual HMAC proof. */
class WifiRadarClient(private val event:(Int,WireTelemetry?,String)->Unit) {
    private data class Challenge(val client:ByteArray,val at:Long)
    private data class Session(
        val channel:SecureWire.Channel,
        val peer:InetAddress,
        val createdAt:Long,
        var lastSeen:Long,
        val gate:AuthenticatedTelemetryGate,
    )
    private val live=AtomicBoolean(false)
    private val random=SecureRandom()
    private var socket:DatagramSocket?=null
    private var thread:Thread?=null
    private val keys=mutableMapOf<Int,ByteArray>()
    fun isRunning():Boolean=live.get()

    @Synchronized fun start(secrets:Map<Int,ByteArray>) {
        check(live.compareAndSet(false,true)) {"radar already running"}
        try {
            require(secrets.keys == setOf(1,2,3))
            require(secrets.values.all { it.size==32 })
            require(secrets.values.map { it.toList() }.toSet().size==3) { "each node needs a distinct key" }
            for((id,key) in secrets) keys[id]=key.copyOf()
            thread=Thread({ runLoop() },"esphub-udp-radar").also {it.start()}
        } catch (e:Exception) {
            live.set(false);keys.values.forEach {it.fill(0)};keys.clear();throw e
        }
    }
    fun stop() {
        live.set(false);socket?.close()
        thread?.interrupt()
        thread?.takeIf{Thread.currentThread()!=it}?.join(1000L)
        // The UDP worker wipes derived session keys in its finally block.
        synchronized(this){keys.values.forEach {it.fill(0)};keys.clear()}
    }
    private fun send(fd:DatagramSocket,host:InetAddress,frame:ByteArray) {
        fd.send(DatagramPacket(frame,frame.size,host,42722))
    }
    private fun runLoop() {
        val pending=mutableMapOf<Int,Challenge>()
        val sessions=mutableMapOf<Int,Session>()
        val broadcast=InetAddress.getByName("192.168.4.255")
        val coordinator=InetAddress.getByName("192.168.4.1")
        try {
            DatagramSocket().use {fd ->
                socket=fd;fd.broadcast=true;fd.soTimeout=300
                val packet=ByteArray(512)
                var lastDiscovery=0L
                while(live.get()){
                    val now=SystemClock.elapsedRealtime()
                    if(now-lastDiscovery>=2500){
                        lastDiscovery=now
                        for(id in 1..3){
                            val session=sessions[id]
                            if(session!=null && now-session.createdAt < 90000 && now-session.lastSeen<5000)continue
                            if(session!=null){session.channel.destroy();sessions.remove(id)}
                            val challenge=Challenge(ByteArray(16).also(random::nextBytes),now)
                            pending[id]=challenge
                            val hello=byteArrayOf(69,72,85,66,1,1,id.toByte())+challenge.client
                            send(fd,broadcast,hello)
                            if(id==1)send(fd,coordinator,hello)
                        }
                    }
                    try {
                        val p=DatagramPacket(packet,packet.size)
                        fd.receive(p)
                        val receivedAt=SystemClock.elapsedRealtime()
                        val size=p.length
                        if(p.port!=42722||!p.address.hostAddress.orEmpty().startsWith("192.168.4."))continue
                        if(size>SecureWire.HEADER_SIZE+WireTelemetry.SIZE+16 && size!=71)continue
                        val data=p.data.copyOfRange(p.offset,p.offset+size)
                        if(size==71 && data.copyOfRange(0,5).contentEquals(byteArrayOf(69,72,85,66,1)) && data[5].toInt()==2){
                            val id=data[6].toInt() and 255
                            if(id !in 1..3)continue
                            val expected=pending[id] ?: continue
                            if(receivedAt-expected.at>5000 || !expected.client.contentEquals(data.copyOfRange(7,23)))continue
                            val device=data.copyOfRange(23,39)
                            val secret=synchronized(this){keys[id]?.copyOf()} ?: continue
                            try {
                                val mac=SecureWire.proof(secret,id,expected.client,device,true)
                                SecureWire.verify(mac,data.copyOfRange(39,71))
                                val keysDerived=SecureWire.derive(secret,id,expected.client,device)
                                val proof=SecureWire.proof(secret,id,expected.client,device,false)
                                send(fd,p.address,byteArrayOf(69,72,85,66,1,3,id.toByte())+proof)
                                sessions.remove(id)?.channel?.destroy()
                                val channel=SecureWire.Channel(keysDerived,id,false)
                                sessions[id]=Session(channel,p.address,receivedAt,receivedAt,
                                    AuthenticatedTelemetryGate(id,channel))
                                pending.remove(id)
                                event(id,null,"Autenticação respondida; aguardando telemetria")
                            }catch(_:SecureWire.AuthenticationException){event(id,null,"Desafio não autenticado")}
                            finally{secret.fill(0)}
                        }else if(size>=SecureWire.HEADER_SIZE+16 && data.copyOfRange(0,5).contentEquals(byteArrayOf(69,72,85,66,1)) && data[5].toInt()==SecureWire.TELEMETRY){
                            val id=data[6].toInt() and 255
                            val session=sessions[id] ?:continue
                            if(p.address!=session.peer)continue
                            try {
                                val report=session.gate.accept(data,receivedAt) ?: continue
                                session.lastSeen=receivedAt
                                event(id,report,"Wi-Fi autenticado • ${session.gate.health.summary()}")
                            } catch (_:IllegalArgumentException) {
                                // A malformed but authenticated frame must not kill the client.
                            }
                        }
                    }catch(_:SocketTimeoutException){ /* wake for stale and handshakes */ }
                }
            }
        }catch(e:SocketException){if(live.get())event(0,null,"Erro UDP: ${e.message}")}
        catch(e:Exception){if(live.get())event(0,null,"Transporte interrompido: ${e.javaClass.simpleName}")}
        finally{
            live.set(false);socket=null
            sessions.values.forEach{it.channel.destroy()}
            sessions.clear();pending.clear()
            synchronized(this){keys.values.forEach {it.fill(0)};keys.clear()}
        }
    }
}
