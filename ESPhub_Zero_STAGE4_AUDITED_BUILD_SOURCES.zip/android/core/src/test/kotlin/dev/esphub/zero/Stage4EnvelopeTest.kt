package dev.esphub.zero

fun main() {
    val secret=ByteArray(32){(it+6).toByte()}
    val client=ByteArray(16){(it+16).toByte()}
    val device=ByteArray(16){(it+72).toByte()}
    val keys=SecureWire.derive(secret,2,client,device)
    val sender=SecureWire.Channel(keys,2,true)
    val receiver=SecureWire.Channel(keys,2,false)
    val valid=sender.seal(SecureWire.TELEMETRY,ByteArray(32),250L)
    val flags=valid.copyOf().also { it[7]=1 }
    try { receiver.open(flags);error("reserved flag accepted") }
    catch (_:SecureWire.AuthenticationException) {}
    val negative=valid.copyOf().also { it[20]=(it[20].toInt() or 0x80).toByte() }
    try { receiver.open(negative);error("negative timestamp accepted") }
    catch (_:SecureWire.AuthenticationException) {}
    check(receiver.open(valid).timestampMs==250L)
    println("PASS: reserved fields and negative timestamps rejected, no replay pollution")
}
