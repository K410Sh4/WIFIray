package dev.esphub.zero

fun main() {
    val secret=ByteArray(32){it.toByte()}
    val client=ByteArray(16){(it+2).toByte()}
    val device=ByteArray(16){(it+40).toByte()}
    val keys=SecureWire.derive(secret,3,client,device)
    val sender=SecureWire.Channel(keys,3,true)
    val receiver=SecureWire.Channel(keys,3,false)
    val f0=sender.seal(SecureWire.TELEMETRY,byteArrayOf(9),100)
    val f1=sender.seal(SecureWire.TELEMETRY,byteArrayOf(8),101)
    val m=receiver.open(f1)
    check(m.sequence==1L && m.payload[0]==8.toByte())
    try {receiver.open(f0);error("late packet must not be accepted")}
    catch (_:SecureWire.ReplayException) {}
    val tampered=f1.copyOf();tampered[tampered.lastIndex]=(tampered.last().toInt() xor 1).toByte()
    try {receiver.open(tampered);error("tampering must not be accepted")}
    catch (_:SecureWire.ReplayException) {} // same sequence rejected before expensive GCM
    val fresh=sender.seal(SecureWire.TELEMETRY,byteArrayOf(7),102)
    fresh[fresh.lastIndex]=(fresh.last().toInt() xor 1).toByte()
    try {receiver.open(fresh);error("invalid tag must not be accepted")}
    catch (_:SecureWire.AuthenticationException) {}
    receiver.destroy()
    check(keys.sessionId.all{it==0.toByte()}&&keys.deviceToApp.all{it==0.toByte()}
        &&keys.appToDevice.all{it==0.toByte()})
    try {receiver.open(fresh);error("destroyed session must reject")}
    catch (_:SecureWire.AuthenticationException) {}
    println("PASS: out-of-order, replay, tamper, session wipe and closed-state guards")
}
