package dev.esphub.zero

fun main() {
    val h=LinkHealth()
    check(h.ageMs(10)==null)
    h.accept(0,100)
    h.accept(3,110)
    check(h.accepted==2L && h.skipped==2L && h.lastSequence==3L)
    check(h.ageMs(130)==20L && h.ageMs(100)==null)
    try { h.accept(3,120);error("must reject repeated sequence") }
    catch (_:IllegalArgumentException) {}
    try { h.accept(-1,120);error("must reject invalid sequence") }
    catch (_:IllegalArgumentException) {}
    check(h.accepted==2L)
    h.replayed++
    h.authFailures++
    check(h.summary().contains("replay 1") && h.summary().contains("tags inválidas 1"))
    println("PASS: authenticated link health gaps/replay/age diagnostics")
}
