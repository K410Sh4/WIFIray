package dev.esphub.zero

fun main(){
    val p=ByteArray(32);p[0]=1;p[1]=2;p[2]=3;p[3]=89;p[4]=(-62).toByte()
    p[7]=48;p[11]=123;p[15]=7;p[19]=3;p[23]=21
    p[24]=1;p[25]=2;p[26]=3;p[27]=4
    val item=checkNotNull(WireTelemetry.parse(p))
    check(item.node==2 && item.rssi == -62 && item.accepted==123L)
    check(item.uptimeMs == 0x0102030400000000L)
    check(WireTelemetry.parse(p.copyOf(31))==null)
    p[5]=1;check(WireTelemetry.parse(p)==null);p[5]=0
    p[3]=101.toByte();check(WireTelemetry.parse(p)==null)
    println("Kotlin telemetry parser: PASS")
}
