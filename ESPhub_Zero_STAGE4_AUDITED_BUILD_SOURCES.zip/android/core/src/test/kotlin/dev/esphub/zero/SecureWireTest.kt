package dev.esphub.zero

fun main() {
    val secret=ByteArray(32){it.toByte()}
    val client=ByteArray(16){it.toByte()}
    val device=ByteArray(16){(it+16).toByte()}
    val keys=SecureWire.derive(secret,2,client,device)
    fun hex(a:ByteArray)=a.joinToString("") { "%02x".format(it.toInt() and 255) }
    check(hex(keys.sessionId)=="6609b4bb5dbc37cc")
    check(hex(keys.deviceToApp)=="da08b93b9e578b6d6127fc21751f84f7866716f5a04fa0cdd349bbbba08a6b7a")
    check(hex(keys.appToDevice)=="0e78043a63c4c11ade00a59743ed33cebca3510c6b90ccb6d245a49d75a35977")
    check(hex(SecureWire.proof(secret,2,client,device,true))=="4209ad43f036a4e6c942b733b56c99d55292991ff457e82de0e6485369ef069d")
    val source=SecureWire.Channel(keys,2,true)
    val mobile=SecureWire.Channel(keys,2,false)
    val frame=source.seal(SecureWire.TELEMETRY,"CSI".toByteArray(),1234)
    check(hex(frame)=="45485542012002006609b4bb5dbc37cc0000000000000000000004d200032d5055174a54a0cbba02b735de3f1e6dcf9a49")
    check(mobile.open(frame).payload.decodeToString()=="CSI")
    try {mobile.open(frame);error("replay must fail")} catch (_: SecureWire.ReplayException) {}
    val cmd=mobile.seal(SecureWire.CONTROL,"stop".toByteArray(),1235)
    check(source.open(cmd).payload.decodeToString()=="stop")
    println("PASS: Kotlin session key derivation, AES-GCM both directions, replay prevention")
}
