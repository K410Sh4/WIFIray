package dev.esphub.zero

fun main() {
    val secret=ByteArray(32){(it+1).toByte()}
    val cn=ByteArray(16){(it+1).toByte()}
    val dn=ByteArray(16){(it+17).toByte()}
    val k=SecureWire.derive(secret,2,cn,dn)
    val sender=SecureWire.Channel(k,2,true)
    val receiver=SecureWire.Channel(k,2,false)
    val gate=AuthenticatedTelemetryGate(2,receiver)
    val payload=ByteArray(32)
    payload[0]=1;payload[1]=2;payload[2]=2;payload[3]=33
    val frame=sender.seal(SecureWire.TELEMETRY,payload,100)
    check(gate.accept(frame,10)?.score==33)
    check(gate.accept(frame,11)==null)
    check(gate.health.replayed==1L && gate.health.lastReceivedMs==10L)
    val damaged=sender.seal(SecureWire.TELEMETRY,payload,101)
    damaged[damaged.lastIndex]=(damaged.last().toInt() xor 1).toByte()
    check(gate.accept(damaged,12)==null)
    check(gate.health.authFailures==1L && gate.health.lastReceivedMs==10L)
    check(gate.accept(sender.seal(SecureWire.TELEMETRY,payload,102),13)!=null)
    check(gate.health.skipped==1L && gate.health.accepted==2L)
    receiver.destroy()
    check(gate.accept(frame,14)==null)
    println("PASS: hostile/replayed UDP frames cannot crash the authenticated telemetry gate")
}
