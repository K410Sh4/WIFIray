package dev.esphub.zero

/** One authenticated node, one ephemeral session. Does not permit exceptions from hostile UDP
 * frames to escape into the receiver loop. Invalid frames never refresh the liveness clock. */
class AuthenticatedTelemetryGate(
    private val node: Int,
    private val channel: SecureWire.Channel,
    val health: LinkHealth = LinkHealth(),
) {
    init { require(node in 1..3) }
    fun accept(frame: ByteArray, nowMs: Long): WireTelemetry? {
        val msg = try {
            channel.open(frame)
        } catch (_: SecureWire.ReplayException) {
            health.replayed++
            return null
        } catch (_: SecureWire.AuthenticationException) {
            health.authFailures++
            return null
        }
        if (msg.kind!=SecureWire.TELEMETRY) return null
        val parsed=WireTelemetry.parse(msg.payload) ?: return null
        if(parsed.node!=node) return null
        health.accept(msg.sequence,nowMs)
        return parsed
    }
}
