package dev.esphub.zero

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Network v1 observation. Status is RF activity, NOT probability of a human. */
data class WireTelemetry(
    val node: Int,
    val state: Int,
    val score: Int,
    val rssi: Int,
    val carriers: Int,
    val accepted: Long,
    val rejected: Long,
    val queueDrops: Long,
    val baseline: Long,
    val uptimeMs: Long,
) {
    companion object {
        const val SIZE=32
        fun parse(p:ByteArray):WireTelemetry? {
            if(p.size!=SIZE||p[0].toInt()!=1)return null
            val node=p[1].toInt() and 255
            val state=p[2].toInt() and 255
            val score=p[3].toInt() and 255
            if(node !in 1..3||state !in 0..5||score>100||p[5].toInt()!=0)return null
            val b=ByteBuffer.wrap(p).order(ByteOrder.BIG_ENDIAN)
            b.position(6)
            val carriers=b.short.toInt() and 65535
            fun u32()=b.int.toLong() and 0xffffffffL
            return WireTelemetry(node,state,score,p[4].toInt(),carriers,u32(),u32(),u32(),u32(),b.long)
                .takeIf {it.uptimeMs>=0}
        }
    }
    fun stateLabel():String=when(state){
        0->"Sem dados CSI";1->"Calibrando";2->"Estável";3->"Alteração de RF"
        4->"Amostras insuficientes";5->"Emissor de referência";else->"Inválido"
    }
}
