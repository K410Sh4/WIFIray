package dev.esphub.zero

/** Host-side diagnostics for authenticated UDP frames, scoped to ONE crypto session.
 * A sequence gap is a skipped count, not proof of RF packet loss: source may fail to send.
 */
class LinkHealth {
    var accepted: Long = 0L
        private set
    var skipped: Long = 0L
        private set
    var lastSequence: Long = -1L
        private set
    var lastReceivedMs: Long = -1L
        private set
    var replayed: Long = 0L
    var authFailures: Long = 0L

    fun accept(sequence: Long, monotonicMs: Long) {
        require(sequence in 0..0xffffffffL && monotonicMs >= 0L)
        require(sequence > lastSequence) { "sequence must advance after AEAD verification" }
        if (lastSequence >= 0L) skipped += sequence - lastSequence - 1L
        lastSequence = sequence
        accepted++
        lastReceivedMs = monotonicMs
    }

    fun ageMs(monotonicMs: Long): Long? =
        if (lastReceivedMs < 0 || monotonicMs < lastReceivedMs) null
        else monotonicMs-lastReceivedMs

    fun summary(): String =
        "recebidos $accepted • saltos de sequência $skipped • replay $replayed • tags inválidas $authFailures"
}
