import sys
import pathlib
import unittest
root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from secure_wire import *

class WireTests(unittest.TestCase):
    def setUp(self):
        self.secret=bytes(range(32)); self.client_nonce=bytes(range(16)); self.device_nonce=bytes(range(16,32))
        self.keys=derive_keys(self.secret,2,self.client_nonce,self.device_nonce)
        self.device=SecureChannel(self.keys,2,"device")
        self.app=SecureChannel(self.keys,2,"app")
    def test_proofs_are_direction_separated(self):
        p=server_hello(self.secret,2,self.client_nonce,self.device_nonce)
        verify_mac(p,server_hello(self.secret,2,self.client_nonce,self.device_nonce))
        self.assertNotEqual(p,client_proof(self.secret,2,self.client_nonce,self.device_nonce))
        with self.assertRaises(AuthenticationError): verify_mac(p,bytes(32))
    def test_keys_are_node_and_epoch_bound(self):
        self.assertNotEqual(self.keys,derive_keys(self.secret,1,self.client_nonce,self.device_nonce))
        self.assertNotEqual(self.keys,derive_keys(self.secret,2,self.client_nonce,bytes([1])*16))
        self.assertNotEqual(self.keys.device_to_app,self.keys.app_to_device)
    def test_bidirectional_authenticated_delivery(self):
        a=self.device.seal(FRAME_TELEMETRY,b"csi-summary",1234)
        self.assertEqual(self.app.open(a),(FRAME_TELEMETRY,b"csi-summary",1234))
        b=self.app.seal(FRAME_CONTROL,b"stop",1235)
        self.assertEqual(self.device.open(b),(FRAME_CONTROL,b"stop",1235))
    def test_replay_and_reorder(self):
        a=self.device.seal(FRAME_TELEMETRY,b"1",1)
        b=self.device.seal(FRAME_TELEMETRY,b"2",2)
        self.assertEqual(self.app.open(b)[1],b"2")
        with self.assertRaises(ReplayError): self.app.open(a)
        with self.assertRaises(ReplayError): self.app.open(b)
    def test_corruption_does_not_consume_seq(self):
        a=self.device.seal(FRAME_TELEMETRY,b"ok",0)
        corrupt=bytearray(a);corrupt[-1]^=1
        with self.assertRaises(AuthenticationError): self.app.open(bytes(corrupt))
        self.assertEqual(self.app.open(a)[1],b"ok")
    def test_truncation_wrong_node_and_wrong_epoch(self):
        a=self.device.seal(FRAME_TELEMETRY,b"payload",17)
        with self.assertRaises(AuthenticationError): self.app.open(a[:-1])
        bad=bytearray(a);bad[6]=3
        with self.assertRaises(AuthenticationError): self.app.open(bytes(bad))
        new=derive_keys(self.secret,2,self.client_nonce,b"\xfe"*16)
        with self.assertRaises(AuthenticationError): SecureChannel(new,2,"app").open(a)
    def test_rekey_before_wrap(self):
        self.device._next_seq=2**32-1
        self.assertTrue(self.device.seal(FRAME_TELEMETRY,b"last",99))
        with self.assertRaises(OverflowError): self.device.seal(FRAME_TELEMETRY,b"no",100)
    def test_payload_bounds(self):
        with self.assertRaises(ValueError): self.device.seal(FRAME_TELEMETRY,b"X"*2049,0)
        with self.assertRaises(ValueError): derive_keys(b"secret",2,self.client_nonce,self.device_nonce)

if __name__=='__main__': unittest.main()
