"""Cross-language wire layout and handshake tests. No claim of hardware interoperability."""
import sys
from pathlib import Path
import secrets
import struct
import unittest

sys.path.insert(0,str(Path(__file__).parents[1]))
import secure_wire as wire

HELLO=struct.Struct(">4sBBB16s")
CHALLENGE=struct.Struct(">4sBBB16s16s32s")
PROOF=struct.Struct(">4sBBB32s")
TELEMETRY=struct.Struct(">BBBBbBHIIIIQ")

class UplinkContractTests(unittest.TestCase):
    def test_frame_sizes_and_big_endian(self):
        self.assertEqual((HELLO.size,CHALLENGE.size,PROOF.size,TELEMETRY.size),(23,71,39,32))
        p=TELEMETRY.pack(1,2,3,89,-62,0,48,123,7,3,21,0x0123456789abcdef)
        self.assertEqual(p.hex(),"01020359c20000300000007b0000000700000003000000150123456789abcdef")
    def test_separate_secrets_and_epoch(self):
        secret1=secrets.token_bytes(32);secret2=secrets.token_bytes(32)
        client=secrets.token_bytes(16);device=secrets.token_bytes(16)
        hello=HELLO.pack(b"EHUB",1,1,2,client)
        self.assertEqual(HELLO.unpack(hello), (b"EHUB",1,1,2,client))
        proof1=wire.server_hello(secret1,2,client,device)
        challenge=CHALLENGE.pack(b"EHUB",1,2,2,client,device,proof1)
        self.assertEqual(CHALLENGE.unpack(challenge)[-1],proof1)
        with self.assertRaises(wire.AuthenticationError):
            wire.verify_mac(proof1,wire.server_hello(secret2,2,client,device))
        app=PROOF.pack(b"EHUB",1,3,2,wire.client_proof(secret1,2,client,device))
        self.assertEqual(len(app),39)
        k=wire.derive_keys(secret1,2,client,device)
        device_chan=wire.SecureChannel(k,2,"device")
        phone_chan=wire.SecureChannel(k,2,"app")
        payload=TELEMETRY.pack(1,2,3,89,-62,0,48,123,7,3,21,123456)
        frame=device_chan.seal(wire.FRAME_TELEMETRY,payload,123456)
        self.assertEqual(len(frame),78)
        self.assertEqual(phone_chan.open(frame)[1],payload)
        with self.assertRaises(wire.ReplayError):phone_chan.open(frame)
        with self.assertRaises(wire.AuthenticationError):
            wire.SecureChannel(wire.derive_keys(secret1,2,client,secrets.token_bytes(16)),2,"app").open(frame)
    def test_malformed_data_no_phantom_person(self):
        payload=TELEMETRY.pack(1,1,5,0,-127,0,0,0,0,0,0,1000)
        self.assertEqual(TELEMETRY.unpack(payload)[2],5) # reference only, never occupancy

if __name__=="__main__": unittest.main()
