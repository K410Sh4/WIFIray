"""ESPhub-Zero transport reference implementation, Python 3.12 + cryptography.

Not a firmware library: normative interoperability/security tests for C/Android ports.
No private keys or passwords belong in code, builds, CI artifacts or public logs.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import hmac
import secrets
import struct
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

MAGIC = b"EHUB"
VERSION = 1
HEADER = struct.Struct(">4sBBBB8sIQH")  # 30 bytes
MAX_PLAINTEXT = 2048
FRAME_TELEMETRY = 0x20
FRAME_CONTROL = 0x30
TAG_SIZE = 16

class AuthenticationError(Exception):
    pass

class ReplayError(AuthenticationError):
    pass


def require_node(node: int) -> None:
    if node not in (1, 2, 3):
        raise ValueError("node must be S3=1, C6=2 or DevKit=3")


def require_secret(secret: bytes) -> None:
    if len(secret) != 32:
        raise ValueError("unique 32-byte device secret required")


def client_hello() -> bytes:
    return secrets.token_bytes(16)


def server_hello(secret: bytes, node: int, client_nonce: bytes, device_nonce: bytes) -> bytes:
    require_secret(secret)
    require_node(node)
    if len(client_nonce) != 16 or len(device_nonce) != 16:
        raise ValueError("nonces must be 16 bytes each")
    body = b"EHUB-v1/DEVICE-PROOF" + bytes((node,)) + client_nonce + device_nonce
    return hmac.digest(secret, body, "sha256")


def client_proof(secret: bytes, node: int, client_nonce: bytes, device_nonce: bytes) -> bytes:
    require_secret(secret)
    require_node(node)
    if len(client_nonce) != 16 or len(device_nonce) != 16:
        raise ValueError("nonces must be 16 bytes each")
    body = b"EHUB-v1/CLIENT-PROOF" + bytes((node,)) + client_nonce + device_nonce
    return hmac.digest(secret, body, "sha256")


def verify_mac(actual: bytes, expected: bytes) -> None:
    if not hmac.compare_digest(actual, expected):
        raise AuthenticationError("authentication failed")


@dataclass(frozen=True)
class Keys:
    session_id: bytes
    device_to_app: bytes
    app_to_device: bytes


def derive_keys(secret: bytes, node: int, client_nonce: bytes, device_nonce: bytes) -> Keys:
    require_secret(secret)
    require_node(node)
    if len(client_nonce) != 16 or len(device_nonce) != 16:
        raise ValueError("nonces must be 16 bytes each")
    info = b"EHUB-v1/SESSION/" + bytes((node,))
    raw = HKDF(algorithm=hashes.SHA256(), length=72,
               salt=client_nonce + device_nonce, info=info).derive(secret)
    return Keys(session_id=raw[:8], device_to_app=raw[8:40], app_to_device=raw[40:72])


class SecureChannel:
    def __init__(self, keys: Keys, node: int, outbound_direction: str):
        require_node(node)
        if len(keys.session_id) != 8 or len(keys.device_to_app) != 32 or len(keys.app_to_device) != 32:
            raise ValueError("invalid keys")
        if outbound_direction not in ("device", "app"):
            raise ValueError("direction must be device or app")
        self.keys = keys
        self.node = node
        self._send = keys.device_to_app if outbound_direction == "device" else keys.app_to_device
        self._receive = keys.app_to_device if outbound_direction == "device" else keys.device_to_app
        self._next_seq = 0
        self._last_seen = -1

    def seal(self, kind: int, payload: bytes, timestamp_ms: int, flags: int = 0) -> bytes:
        if kind not in (FRAME_TELEMETRY, FRAME_CONTROL):
            raise ValueError("invalid frame kind")
        if len(payload) > MAX_PLAINTEXT or not 0 <= timestamp_ms < 2**64 or not 0 <= flags <= 255:
            raise ValueError("invalid telemetry frame")
        if self._next_seq >= 2**32:
            raise OverflowError("rekey before sequence wrap")
        seq = self._next_seq
        self._next_seq += 1
        header = HEADER.pack(MAGIC, VERSION, kind, self.node, flags,
                             self.keys.session_id, seq, timestamp_ms, len(payload))
        nonce = self.keys.session_id + struct.pack(">I", seq)
        return header + AESGCM(self._send).encrypt(nonce, payload, header)

    def open(self, frame: bytes) -> tuple[int, bytes, int]:
        if len(frame) < HEADER.size + TAG_SIZE:
            raise AuthenticationError("truncated frame")
        magic, version, kind, node, flags, session_id, seq, ts, length = HEADER.unpack_from(frame)
        if (magic != MAGIC or version != VERSION or node != self.node or
                session_id != self.keys.session_id or
                kind not in (FRAME_TELEMETRY, FRAME_CONTROL) or length > MAX_PLAINTEXT or
                len(frame) != HEADER.size + length + TAG_SIZE):
            raise AuthenticationError("invalid envelope")
        if seq <= self._last_seen:
            raise ReplayError("sequence replay or out of order")
        nonce = session_id + struct.pack(">I", seq)
        try:
            plaintext = AESGCM(self._receive).decrypt(nonce, frame[HEADER.size:], frame[:HEADER.size])
        except Exception as exc:
            raise AuthenticationError("bad authentication tag") from exc
        self._last_seen = seq  # only after tag validation
        return kind, plaintext, ts
