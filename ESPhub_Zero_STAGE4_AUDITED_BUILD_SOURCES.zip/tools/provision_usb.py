#!/usr/bin/env python3
"""Physical USB provisioning for one ESPhub node, not a remote or OTA interface.

Uses getpass (no local terminal echo), never prints credentials, and atomically
creates a private 0600 owner-only key file AFTER MCU acknowledges key storage.
The MCU UART remains a trusted physical channel; flash/NVS encryption is NOT guaranteed.
Install: python -m pip install pyserial
"""
from __future__ import annotations
import argparse
import getpass
import os
from pathlib import Path
import secrets
import sys
import time

NODE_IDS={"s3":1,"c6":2,"devkit":3}
ACK=b"App key stored"


def clean_ssid(ssid:str)->str:
    if not 1<=len(ssid)<=32 or any(ord(c)<33 or c in '\"\\' for c in ssid):
        raise ValueError("SSID: 1..32 printable characters, no spaces, quotes or backslash")
    return ssid


def clean_password(pw:str)->str:
    if not 16<=len(pw)<=63 or any(ord(c)<33 or ord(c)>126 or c in '\"\\' for c in pw):
        raise ValueError("Wi-Fi passphrase: 16..63 printable nonspace ASCII, no quotes or backslash")
    return pw


def create_private_file(path:Path, content:str):
    # O_EXCL and NOFOLLOW stop overwrites and symlink redirection.
    flags=os.O_WRONLY|os.O_CREAT|os.O_EXCL
    if hasattr(os,"O_NOFOLLOW"): flags|=os.O_NOFOLLOW
    fd=os.open(path,flags,0o600)
    try:
        with os.fdopen(fd,"w",encoding="ascii") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
    except BaseException:
        path.unlink(missing_ok=True)
        raise


def await_ack(port, token:bytes=ACK, timeout:float=8.0)->bool:
    end=time.monotonic()+timeout
    buffer=bytearray()
    while time.monotonic()<end:
        data=port.read(64)
        if data:
            buffer.extend(data)
            if token in buffer:
                return True
            del buffer[:-256]
    return False


def perform(port, node:str, ssid:str|None, wifi_password:str, secret_hex:str,
            owner_file:Path, ack_timeout:float=8.0)->None:
    """Sends Wi-Fi then unique app secret to ONE USB-attached node."""
    if node not in NODE_IDS:raise ValueError("unknown node")
    if owner_file.exists():raise FileExistsError("key file already exists; refusing overwrite")
    clean_password(wifi_password)
    if node!="s3":clean_ssid(ssid or "")
    if len(secret_hex)!=64 or any(c not in "0123456789abcdef" for c in secret_hex):
        raise ValueError("expected a fresh 32-byte random key")
    # No command contents are sent to stdout, stderr, log files or Python exceptions.
    cmd=("ap-pass " if node=="s3" else "join "+ssid+" ")+wifi_password+"\n"
    port.write(cmd.encode("ascii"));port.flush()
    if not await_ack(port,b"credentials saved",ack_timeout):
        raise RuntimeError("MCU did not acknowledge Wi-Fi credentials; key not installed")
    port.write(("key "+secret_hex+"\n").encode("ascii"));port.flush()
    if not await_ack(port,ACK,ack_timeout):
        raise RuntimeError("MCU did not acknowledge key storage; inspect board using trusted USB")
    # Keep only this node's secret in the file; no password is written to disk.
    create_private_file(owner_file, f"node={node}\napp_secret_hex={secret_hex}\n")
    port.write(b"restart\n");port.flush()


def main(argv=None)->int:
    parser=argparse.ArgumentParser(description="ESPhub USB provisioning; no secrets in logs")
    parser.add_argument("--port",required=True,help="Physical serial device, e.g. /dev/ttyUSB0 or COM3")
    parser.add_argument("--node",choices=NODE_IDS,required=True)
    parser.add_argument("--ssid",default="ESPHUB-ZERO",help="S3 AP SSID: ESPHUB-ZERO")
    parser.add_argument("--key-file",type=Path,required=True,help="New owner-only key file; never overwritten")
    parser.add_argument("--baud",type=int,default=115200)
    args=parser.parse_args(argv)
    if args.key_file.exists():parser.error("key-file already exists; choose a new private path")
    ssid=None if args.node=="s3" else clean_ssid(args.ssid)
    password=clean_password(getpass.getpass("Wi-Fi password (not echoed): "))
    secret_hex=secrets.token_hex(32)
    try:
        import serial  # noqa: PLC0415 - only needed when used with real hardware
    except ImportError:
        print("Install pyserial: python -m pip install pyserial",file=sys.stderr)
        return 2
    try:
        with serial.Serial(args.port,args.baud,timeout=.2,write_timeout=3) as port:
            time.sleep(.6) # Serial-open may reset ESP boards.
            port.reset_input_buffer()
            perform(port,args.node,ssid,password,secret_hex,args.key_file)
    except (OSError,RuntimeError,ValueError) as exc:
        # Exception text must never contain secrets or raw command strings.
        print(f"Provisioning did not complete: {type(exc).__name__}",file=sys.stderr)
        return 1
    print("Provisioning acknowledged; key saved to owner-only local file. Handle it as a secret.")
    return 0

if __name__=="__main__":raise SystemExit(main())
