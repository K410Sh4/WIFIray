import importlib.util
import os
from pathlib import Path
import tempfile
import unittest

SOURCE=Path(__file__).resolve().parents[1]/'provision_usb.py'
spec=importlib.util.spec_from_file_location('esphub_usb',SOURCE)
tool=importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)

class FakeSerial:
    def __init__(self,ack1=True,ack2=True):
        self.commands=[]
        self.reads=[b'credentials saved' if ack1 else b'',b'App key stored' if ack2 else b'']
    def write(self,cmd):self.commands.append(cmd)
    def flush(self):pass
    def read(self,n):return self.reads.pop(0) if self.reads else b''

class Tests(unittest.TestCase):
    def test_validate(self):
        with self.assertRaises(ValueError):tool.clean_password('short')
        with self.assertRaises(ValueError):tool.clean_ssid('not okay')
        with self.assertRaises(ValueError):tool.clean_password('q'*16+'\\')
    def test_serial_sequence_permissions_no_password_storage(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'key.txt'; serial=FakeSerial();key='c1'*32
            tool.perform(serial,'c6','ESPHUB-ZERO','very-strong-passphrase',key,f,ack_timeout=.01)
            self.assertEqual(len(serial.commands),3)
            self.assertIn(b'join ESPHUB-ZERO',serial.commands[0])
            self.assertEqual(serial.commands[1],('key '+key+'\n').encode())
            self.assertEqual(serial.commands[2],b'restart\n')
            self.assertEqual(f.stat().st_mode & 0o777,0o600)
            self.assertIn(key,f.read_text())
            self.assertNotIn('very-strong-passphrase',f.read_text())
            with self.assertRaises(FileExistsError):
                tool.perform(FakeSerial(),'c6','ESPHUB-ZERO','very-strong-passphrase',key,f,ack_timeout=.01)
    def test_timeout_no_keyfile(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'key.txt';serial=FakeSerial(ack1=True,ack2=False)
            with self.assertRaises(RuntimeError):
                tool.perform(serial,'s3',None,'very-strong-passphrase','ab'*32,f,ack_timeout=.01)
            self.assertFalse(f.exists())
            self.assertEqual(len(serial.commands),2)
    def test_no_overwrite_symlink(self):
        if not hasattr(os,'O_NOFOLLOW'):self.skipTest('platform missing O_NOFOLLOW')
        with tempfile.TemporaryDirectory() as d:
            target=Path(d)/'target';target.write_text('UNCHANGED')
            alias=Path(d)/'alias';alias.symlink_to(target)
            with self.assertRaises(OSError):tool.create_private_file(alias,'SECRET')
            self.assertEqual(target.read_text(),'UNCHANGED')

if __name__=='__main__':unittest.main()
