# ESPhub Zero — Stage 4 build-readiness candidate

**Source-only, NOT an APK/BIN release.** This package begins with the independent Zero code and does not import pre-Zero products. End-to-end ESP-IDF and Android compilers are unavailable in the current local environment. CI is prepared and must run in a NEW empty repository, not the repository containing unrelated projects.

- Hardware roles: S3 N16R8 reference AP; C6 + ESP32 DevKit V1 receive CSI.
- Wi-Fi RF reference on UDP 42720; authenticated Wi-Fi uplink to Android on UDP 42722; BLE not required for this prototype.
- Four binary outputs are **gated** on all build jobs and host tests being green, without fabricating output files.
- Real-world protection against eavesdropping of unencrypted NVS, USB physical access, human-specific detection, Secure Boot / Flash Encryption and OTA is NOT verified or promised.

Read `docs/STAGE4_BUILD_AUDIT.md`, `COMECE_AQUI.md`, `docs/SECURITY.md` and `docs/PROTOCOL.md`. Run `bash ci/test_local.sh`. After a clean repo exists, GitHub workflow `.github/workflows/build-stage4.yml` builds all four artifacts and rejects any incomplete set.
