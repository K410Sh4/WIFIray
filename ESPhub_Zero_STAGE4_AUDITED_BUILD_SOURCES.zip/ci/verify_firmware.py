#!/usr/bin/env python3
"""Inspect output of IDF merge-bin, source board profiles, partition metadata."""
import argparse
import hashlib
import json
from pathlib import Path

FLASH = {'esp32s3': 16 * 1024 * 1024, 'esp32c6': 4 * 1024 * 1024, 'esp32': 4 * 1024 * 1024}
BOOT = {'esp32s3': 0, 'esp32c6': 0, 'esp32': 0x1000}

def check(root: Path, target: str) -> dict:
    if target not in FLASH:
        raise ValueError('unknown target')
    b=root/'firmware'/'build'
    config=(b/'sdkconfig').read_text() if (b/'sdkconfig').exists() else (root/'firmware'/'sdkconfig').read_text()
    if f'CONFIG_IDF_TARGET="{target}"' not in config:
        raise ValueError('compiled target does not match expected hardware')
    expected='16mb' if target=='esp32s3' else '4mb'
    if f'CONFIG_PARTITION_TABLE_CUSTOM_FILENAME="partitions_{expected}.csv"' not in config:
        raise ValueError('partition profile does not match target')
    if target=='esp32s3' and 'CONFIG_ESPTOOLPY_FLASHSIZE_16MB=y' not in config:
        raise ValueError('S3 flash not configured for 16 MB')
    if target!='esp32s3' and 'CONFIG_ESPTOOLPY_FLASHSIZE_4MB=y' not in config:
        raise ValueError('non-S3 flash not configured for 4 MB')
    meta=json.loads((b/'flasher_args.json').read_text())
    blobs=meta.get('flash_files', {})
    if not any('bootloader' in x for x in blobs.values()):
        raise ValueError('bootloader missing')
    if not any('partition' in x for x in blobs.values()):
        raise ValueError('partition table missing')
    if not any('esphub_zero_radio.bin' in x for x in blobs.values()):
        raise ValueError('app missing')
    image=b/f'ESPhub_Zero_{target}_FULL.bin'
    data=image.read_bytes()
    if not data or data[BOOT[target]] != 0xE9 or len(data)>FLASH[target]:
        raise ValueError('missing ESP bootloader magic or image exceeds flash')
    if target=='esp32' and data[0]!=0xFF:
        raise ValueError('ESP32 bootloader expected at 0x1000 (0x0 must be blank)')
    return {'target':target,'image':str(image),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--target',choices=FLASH,required=True)
    args=parser.parse_args()
    print(json.dumps(check(args.root,args.target),sort_keys=True))
