"""Tests the artifact gate using synthetic files, NOT simulated hardware performance."""
import importlib.util
import json
import tempfile
from pathlib import Path
import unittest

SCRIPT=Path(__file__).resolve().parents[1]/'verify_firmware.py'
SPEC=importlib.util.spec_from_file_location('stage4_verify', SCRIPT)
MOD=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MOD)

class VerifyFirmwareTests(unittest.TestCase):
    def create_fixture(self, root, chip):
        build=root/'firmware'/'build'; build.mkdir(parents=True)
        size='16mb' if chip=='esp32s3' else '4mb'
        (build/'sdkconfig').write_text(
            f'CONFIG_IDF_TARGET="{chip}"\n'
            f'CONFIG_ESPTOOLPY_FLASHSIZE_{size.upper()}=y\n'
            f'CONFIG_PARTITION_TABLE_CUSTOM_FILENAME="partitions_{size}.csv"\n')
        (build/'flasher_args.json').write_text(json.dumps({'flash_files':{
            '0x0':'bootloader/bootloader.bin',
            '0x8000':'partition_table/partition-table.bin',
            '0x10000':'esphub_zero_radio.bin'}}))
        data=bytearray(0x12000)
        data[0]=0xff if chip=='esp32' else 0xe9
        data[0x1000]=0xe9
        (build/f'ESPhub_Zero_{chip}_FULL.bin').write_bytes(data)
        return build
    def test_all_three_targets(self):
        for chip in MOD.FLASH:
            with self.subTest(chip=chip),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);self.create_fixture(root,chip)
                self.assertEqual(MOD.check(root,chip)['target'],chip)
    def test_wrong_target_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.create_fixture(root,'esp32')
            with self.assertRaises(ValueError):MOD.check(root,'esp32c6')
    def test_bad_image_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);b=self.create_fixture(root,'esp32')
            image=b/'ESPhub_Zero_esp32_FULL.bin'
            buf=bytearray(image.read_bytes());buf[0x1000]=0;image.write_bytes(buf)
            with self.assertRaises(ValueError):MOD.check(root,'esp32')
    def test_wrong_partition_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);b=self.create_fixture(root,'esp32')
            f=b/'sdkconfig';f.write_text(f.read_text().replace('partitions_4mb.csv','partitions_16mb.csv'))
            with self.assertRaises(ValueError):MOD.check(root,'esp32')
    def test_missing_parts_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);b=self.create_fixture(root,'esp32')
            (b/'flasher_args.json').write_text(json.dumps({'flash_files':{'0x10000':'esphub_zero_radio.bin'}}))
            with self.assertRaises(ValueError):MOD.check(root,'esp32')

if __name__=='__main__':unittest.main()
