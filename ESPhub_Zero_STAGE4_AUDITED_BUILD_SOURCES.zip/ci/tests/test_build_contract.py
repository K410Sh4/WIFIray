"""No ESP-IDF present on host: checks ONLY build contract, never claims binary builds."""
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[2]

class BuildContracts(unittest.TestCase):
    def test_target_profile_sizes(self):
        for chip,size in (('esp32s3','16mb'),('esp32c6','4mb'),('esp32','4mb')):
            defaults=(ROOT/f'firmware/sdkconfig.defaults.{chip}').read_text()
            self.assertIn(f'CONFIG_PARTITION_TABLE_CUSTOM_FILENAME="partitions_{size}.csv"',defaults)
            self.assertIn(f'CONFIG_ESPTOOLPY_FLASHSIZE_{size.upper()}=y',defaults)
    def test_factory_partition_fits(self):
        for size in ('4mb','16mb'):
            csv=(ROOT/f'firmware/partitions_{size}.csv').read_text()
            self.assertIn('factory, app, factory, 0x10000',csv)
            self.assertLess(0x10000+int(csv.split('factory, app, factory, 0x10000, 0x')[1].split(',')[0],16),
                {'4mb':4,'16mb':16}[size]*1024*1024)
    def test_build_artifact_gate(self):
        wf=(ROOT/'.github/workflows/build-stage4.yml').read_text()
        for job in ('quality:','firmware:','android:','verify-package:'):
            self.assertIn(job,wf)
        for suffix in ('esp32s3','esp32c6','esp32'):
            self.assertIn(suffix,wf)
        self.assertIn('needs: [quality, firmware, android]',wf)
    def test_no_secrets_in_source(self):
        for f in (ROOT/'firmware/main').glob('*.cpp'):
            s=f.read_text()
            self.assertNotIn('password="',s)
            self.assertNotIn('secret="',s)

if __name__=='__main__':
    unittest.main()
