# ESPhub Zero — Marco 4

1. Read `docs/STAGE4_BUILD_AUDIT.md` and `docs/SECURITY.md` before flashing any hardware. This package contains **source**, not the four installable binaries.
2. Run locally `bash ci/test_local.sh` (requires C++, Python cryptography, JDK + kotlinc). This checks libraries and build contract, not native Android/ESP firmware.
3. Create a NEW EMPTY private GitHub repository; upload THIS Stage 4 project without importing or branching from the previous repository.
4. Run Actions workflow **ESPhub Zero - Stage 4 complete candidate**. Only the green `verify-package` artifact contains exactly 1 debug APK + 3 FULL.bin with hashes.
5. Confirm actual flash size on each board first (S3 16 MiB, C6 4 MiB and DevKit 4 MiB profiles are assumptions until physically verified). Never write the wrong target. `FULL.bin` is intended at offset 0x0 after verification by build validator.
6. USB provisioning and installation steps are in `docs/STAGE3_MILESTONE.md` and `docs/STAGE4_BUILD_AUDIT.md`; do not send secret files to chat/GitHub.
7. A successful build does NOT prove physical CSI behavior, radio performance, correct human detection or production security.
