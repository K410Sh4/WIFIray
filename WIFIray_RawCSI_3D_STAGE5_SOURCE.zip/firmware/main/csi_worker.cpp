#include "csi_worker.h"
#include "board.h"
#include "radio.h"
#include "eh_radar.h"
#include "telemetry.h"
#include "raw_csi.h"
#include <atomic>
#include <cstring>
#include "esp_wifi.h"
#include "esp_timer.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"

static const char* TAG="ehub.csi";
static constexpr int kQueueDepth=16;
static constexpr int kMaxIqBytes=512;
struct CsiSample { uint16_t length; int8_t rssi; int8_t iq[kMaxIqBytes]; };
static QueueHandle_t s_queue=nullptr;
static std::atomic<uint32_t> s_overflow{0};
static std::atomic<uint32_t> s_filtered{0};
static uint8_t s_bssid[6]={};
static bool s_csi_ready=false;

static void on_csi(void*, wifi_csi_info_t* info){
    if(!s_csi_ready || !s_queue || !info || !info->buf ||
        (info->first_word_invalid && info->len<=4)) return;
    // Limit the radar to frames sent by its provisioned reference AP.
    if(memcmp(s_bssid,info->mac,6)!=0){s_filtered.fetch_add(1,std::memory_order_relaxed);return;}
    const size_t skip=info->first_word_invalid?4:0;
    const size_t n=info->len-skip;
    if(n<32 || n>kMaxIqBytes || (n&1)) {s_overflow.fetch_add(1,std::memory_order_relaxed);return;}
    CsiSample sample{};
    sample.length=static_cast<uint16_t>(n);
    sample.rssi=info->rx_ctrl.rssi;
    memcpy(sample.iq,info->buf+skip,n); // CSI pointer becomes invalid after callback returns.
    if(xQueueSend(s_queue,&sample,0)!=pdTRUE)s_overflow.fetch_add(1,std::memory_order_relaxed);
}

esp_err_t start_csi_pipeline(){
    if(s_csi_ready) return ESP_OK;
    wifi_ap_record_t current{};
    esp_err_t err=esp_wifi_sta_get_ap_info(&current);
    if(err!=ESP_OK)return err;
    memcpy(s_bssid,current.bssid,6);
    if(!s_queue)s_queue=xQueueCreate(kQueueDepth,sizeof(CsiSample));
    if(!s_queue)return ESP_ERR_NO_MEM;
    wifi_csi_config_t cfg{};
#if CONFIG_IDF_TARGET_ESP32C6
    cfg.enable=true;
    cfg.acquire_csi_legacy=true;
    cfg.acquire_csi_ht20=true;
    cfg.acquire_csi_ht40=true;
    cfg.acquire_csi_su=false; // S3 reference AP uses 802.11n, no HE-LTF assumed.
    cfg.acquire_csi_mu=false;
    cfg.acquire_csi_dcm=false;
    cfg.acquire_csi_beamformed=false;
    cfg.acquire_csi_he_stbc=0;
    cfg.val_scale_cfg=false;
#else
    cfg.lltf_en=true;
    cfg.htltf_en=true;
    cfg.stbc_htltf2_en=false;
    cfg.ltf_merge_en=false;
    cfg.channel_filter_en=false;
    cfg.manu_scale=false;
    cfg.shift=0;
#endif
    if((err=esp_wifi_set_csi_config(&cfg))!=ESP_OK)return err;
    if((err=esp_wifi_set_csi_rx_cb(on_csi,nullptr))!=ESP_OK)return err;
    if((err=esp_wifi_set_csi(true))!=ESP_OK)return err;
    s_csi_ready=true;
    ESP_LOGI(TAG,"CSI enabled for provisioned AP MAC; callback copies into bounded queue");
    return ESP_OK;
}

void csi_report_task(void*) {
    esphub::RadarCore core(esphub::Config{12,20,.17f,.08f,3,5});
    int64_t last=esp_timer_get_time();
    int rssi_total=0;int rssi_count=0;
    bool was_connected=false;
    int64_t next_raw_us=0;
    uint32_t raw_serial=0;
    for(;;){
        const bool online=radio_connected();
        if(!online){
            if(was_connected){
                s_csi_ready=false;
                (void)esp_wifi_set_csi(false);
                if(s_queue) {
                    CsiSample discard{};
                    while(xQueueReceive(s_queue,&discard,0)==pdTRUE){}
                }
                core.reset_baseline();
                clear_raw_csi();
                publish_radio_snapshot(RadioSnapshot{});
            }
            was_connected=false;
            vTaskDelay(pdMS_TO_TICKS(200));last=esp_timer_get_time();continue;
        }
        if(!was_connected){
            esp_err_t err=start_csi_pipeline();
            if(err!=ESP_OK){ESP_LOGE(TAG,"CSI start error: %s",esp_err_to_name(err));vTaskDelay(pdMS_TO_TICKS(1500));continue;}
            core.reset_baseline();
            clear_raw_csi();
            publish_radio_snapshot(RadioSnapshot{});
            next_raw_us=esp_timer_get_time();
            was_connected=true;last=esp_timer_get_time();
        }
        CsiSample sample{};
        if(s_queue && xQueueReceive(s_queue,&sample,pdMS_TO_TICKS(100))==pdTRUE){
            if(core.ingest_iq(sample.iq,sample.length)){
                rssi_total+=sample.rssi;++rssi_count;
                // Maximum 8 raw CSI frames/s; publish outside the Wi-Fi callback.
                const int64_t at=esp_timer_get_time();
                if(at>=next_raw_us){
                    RawCsiSnapshot raw{};
                    raw.serial=++raw_serial;
                    if(!raw.serial)raw.serial=++raw_serial;
                    raw.uptime_ms=static_cast<uint64_t>(at/1000);
                    raw.iq_bytes=sample.length;raw.rssi=sample.rssi;
                    memcpy(raw.iq,sample.iq,sample.length);
                    publish_raw_csi(raw);
                    next_raw_us=at+125000; // 8Hz, never "catch up" with a burst
                }
            }
        }
        if(esp_timer_get_time()-last>=1000000){
            const auto obs=core.complete_window();
            const int rssi=rssi_count?rssi_total/rssi_count:-127;
            RadioSnapshot snapshot{};
            snapshot.state=static_cast<uint8_t>(obs.state);
            snapshot.score=obs.score;
            snapshot.rssi=static_cast<int8_t>(rssi);
            snapshot.carriers=obs.active_carriers;
            snapshot.accepted=obs.accepted_frames;
            snapshot.rejected=obs.dropped_frames;
            snapshot.queue_drops=s_overflow.load(std::memory_order_relaxed);
            snapshot.baseline=obs.baseline_windows;
            snapshot.uptime_ms=static_cast<uint64_t>(esp_timer_get_time()/1000);
            publish_radio_snapshot(snapshot);
            ESP_LOGI(TAG,"node=%d state=%u score=%u accepted=%lu rejected=%lu queue_drops=%lu filtered=%lu baseline=%lu carriers=%u rssi=%d",
                kNodeId,static_cast<unsigned>(obs.state),obs.score,
                static_cast<unsigned long>(obs.accepted_frames),static_cast<unsigned long>(obs.dropped_frames),
                static_cast<unsigned long>(s_overflow.exchange(0)),
                static_cast<unsigned long>(s_filtered.exchange(0)),
                static_cast<unsigned long>(obs.baseline_windows),obs.active_carriers,rssi);
            last=esp_timer_get_time();rssi_total=0;rssi_count=0;
        }
    }
}
