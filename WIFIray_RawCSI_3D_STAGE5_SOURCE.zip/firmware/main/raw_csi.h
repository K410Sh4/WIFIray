#pragma once
#include <cstdint>
// Stores at most one CSI frame. No on-device raw history; no unbounded queue.
inline constexpr uint16_t kRawSnapshotIqMax = 512;
struct RawCsiSnapshot {
    uint32_t serial = 0;
    uint64_t uptime_ms = 0;
    uint16_t iq_bytes = 0;
    int8_t rssi = -127;
    int8_t iq[kRawSnapshotIqMax]{};
};
void publish_raw_csi(const RawCsiSnapshot& sample);
bool read_latest_raw_csi(uint32_t previous_serial, RawCsiSnapshot& out);
uint32_t latest_raw_serial();
void clear_raw_csi();
