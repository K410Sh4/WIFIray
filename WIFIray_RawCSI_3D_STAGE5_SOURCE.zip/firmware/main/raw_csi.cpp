#include "raw_csi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/portmacro.h"
#include <cstring>

static portMUX_TYPE s_rawGuard=portMUX_INITIALIZER_UNLOCKED;
static RawCsiSnapshot s_latest{};
void publish_raw_csi(const RawCsiSnapshot& sample) {
    if (!sample.serial || sample.iq_bytes<32 || sample.iq_bytes>kRawSnapshotIqMax ||
        (sample.iq_bytes & 1)) return;
    portENTER_CRITICAL(&s_rawGuard);
    s_latest=sample;
    portEXIT_CRITICAL(&s_rawGuard);
}
bool read_latest_raw_csi(uint32_t previous_serial, RawCsiSnapshot& out) {
    portENTER_CRITICAL(&s_rawGuard);
    if (!s_latest.serial || s_latest.serial==previous_serial) {
        portEXIT_CRITICAL(&s_rawGuard);
        return false;
    }
    out=s_latest;
    portEXIT_CRITICAL(&s_rawGuard);
    return true;
}
uint32_t latest_raw_serial(){
    portENTER_CRITICAL(&s_rawGuard);
    const uint32_t serial=s_latest.serial;
    portEXIT_CRITICAL(&s_rawGuard);
    return serial;
}
void clear_raw_csi(){
    portENTER_CRITICAL(&s_rawGuard);
    memset(&s_latest,0,sizeof(s_latest));
    portEXIT_CRITICAL(&s_rawGuard);
}
