#pragma once
#include <cstddef>
#include <cstdint>
#include "eh_wire.h"

namespace esphub {
// Raw CSI v1: 20-byte envelope + interleaved signed I/Q copied from the
// Wi-Fi CSI callback by a bounded queue. DO NOT assume that each I/Q pair is
// a stable, absolute spatial coordinate or that both chips have equal bins.
inline constexpr size_t kRawHeaderBytes = 20;
inline constexpr size_t kRawMinIqBytes = 32;
inline constexpr size_t kRawMaxIqBytes = 512;
inline constexpr size_t kRawMaxPayload = kRawHeaderBytes + kRawMaxIqBytes;
inline constexpr uint8_t kRawKind = 0x21;
struct RawCsiView {
    uint8_t node = 0;
    int8_t rssi = -127;
    uint32_t serial = 0;
    uint64_t uptime_ms = 0;
    const int8_t* iq = nullptr;
    uint16_t iq_bytes = 0;
};
inline bool encodeRawCsi(const RawCsiView& v, uint8_t* dst, size_t cap, size_t& used) {
    used = 0;
    if (!dst || (v.node != 2 && v.node != 3) || !v.iq ||
        v.iq_bytes < kRawMinIqBytes || v.iq_bytes > kRawMaxIqBytes ||
        (v.iq_bytes & 1) || cap < kRawHeaderBytes + v.iq_bytes) return false;
    dst[0] = 1;
    dst[1] = v.node;
    dst[2] = 0; // reserved; fail closed on unknown flags
    dst[3] = static_cast<uint8_t>(v.rssi);
    be16(dst + 4, v.iq_bytes);
    be16(dst + 6, 0); // reserved
    be32(dst + 8, v.serial);
    be64(dst + 12, v.uptime_ms);
    for (size_t i = 0; i < v.iq_bytes; ++i) dst[kRawHeaderBytes+i] = static_cast<uint8_t>(v.iq[i]);
    used = kRawHeaderBytes + v.iq_bytes;
    return true;
}
inline bool decodeRawCsi(const uint8_t* bytes, size_t n, RawCsiView& v) {
    if (!bytes || n < kRawHeaderBytes || n > kRawMaxPayload || bytes[0] != 1 ||
        (bytes[1] != 2 && bytes[1] != 3) || bytes[2] != 0 || read16(bytes+6) != 0) return false;
    const uint16_t iqBytes = read16(bytes+4);
    if (iqBytes < kRawMinIqBytes || iqBytes > kRawMaxIqBytes || (iqBytes & 1) ||
        n != kRawHeaderBytes + iqBytes) return false;
    v.node=bytes[1];v.rssi=static_cast<int8_t>(bytes[3]);
    v.serial=read32(bytes+8);v.uptime_ms=read64(bytes+12);
    v.iq=reinterpret_cast<const int8_t*>(bytes+kRawHeaderBytes);
    v.iq_bytes=iqBytes;
    return true;
}
}
