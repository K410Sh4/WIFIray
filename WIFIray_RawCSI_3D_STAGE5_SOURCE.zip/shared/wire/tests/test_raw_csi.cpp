#include "eh_raw_csi.h"
#include <array>
#include <cassert>
#include <cstdint>
int main(){
    std::array<int8_t,512> iq{};
    for (size_t i=0;i<iq.size();++i) iq[i]=static_cast<int8_t>(i*13);
    esphub::RawCsiView value{};value.node=2;value.rssi=-50;value.serial=42;
    value.uptime_ms=1234;value.iq=iq.data();value.iq_bytes=512;
    std::array<uint8_t,esphub::kRawMaxPayload> buffer{};
    size_t used=0;
    assert(esphub::encodeRawCsi(value,buffer.data(),buffer.size(),used));
    assert(used==532);
    esphub::RawCsiView parsed{};
    assert(esphub::decodeRawCsi(buffer.data(),used,parsed));
    assert(parsed.serial==42 && parsed.rssi==-50 && parsed.iq_bytes==512);
    for(size_t i=0;i<512;++i)assert(parsed.iq[i]==iq[i]);
    buffer[2]=1;assert(!esphub::decodeRawCsi(buffer.data(),used,parsed));buffer[2]=0;
    buffer[6]=1;assert(!esphub::decodeRawCsi(buffer.data(),used,parsed));buffer[6]=0;
    assert(!esphub::decodeRawCsi(buffer.data(),used-1,parsed));
    value.iq_bytes=513;assert(!esphub::encodeRawCsi(value,buffer.data(),buffer.size(),used));
    value.iq_bytes=510;value.node=1;
    assert(!esphub::encodeRawCsi(value,buffer.data(),buffer.size(),used));
}
