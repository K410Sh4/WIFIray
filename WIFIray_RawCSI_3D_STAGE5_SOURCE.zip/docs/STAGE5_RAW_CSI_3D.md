# WIFIray Marco 5 — CSI bruto, modelo local e visualização 3D experimental

## Situação real
Fonte implementado para uma nova versão dos 3 firmwares e do APK. Ainda NÃO é um
APK/BIN validado: requer build real e ensaio com as placas antes de distribuição.
Não grave o firmware antigo junto com o aplicativo novo para tirar conclusões;
status v1 continua, CSI bruto exige novo firmware nos RECEPTORES.

## Cadeia de dados
S3 AP + respostas unicast (sem upload CSI) -> callbacks CSI do C6/DevKit ->
fila finita (16) -> worker CSI -> snapshot bruto MAIS RECENTE (512 I/Q no máximo)
-> UDP AES-256-GCM da sessão HMAC/HKDF existente -> parser estrito do Android
-> fila descartável de duas amostras -> modelo não supervisionado no celular
-> visualização OpenGL ES 2.0.

Protocolo: tipo autenticado 0x20 permanece status de 32 bytes, a ~1 Hz.
Novo tipo autenticado 0x21: payload 20+N, N par entre 32 e 512.
0:version=1; 1:node=2/3; 2:flags=0; 3:signed RSSI; 4-5:N,
6-7:reserved=0; 8-11:serial; 12-19:uptime ms; 20..:signed I/Q interleaved.
Mesmo cabeçalho EHub e mesma sequência AES-GCM do status — não há nova chave
nem novo handshake. Pacote completo <= 578 bytes; sem fragmentação de aplicação.
Até 8 publicações por segundo por RECEPTOR. A CPU/UDP pode entregar menos.
Uma amostra atrasada >500 ms não é retransmitida, e não há histórico de IQ.

## IA local: limites honestos
Modelo adaptativo não supervisionado de 16 bandas. Aprende as primeiras 48
amostras (~6 segundos em fluxo contínuo de 8 Hz); estima diferenças relativas
por banda e congela a referência durante desvios grandes. É aprendizado de
padrão RF, NÃO classificador de pessoas, pose, orientação nem imagem humana.
As diferenças de mapeamento subportadora, frequência e ganho entre chips não
foram calibradas; por isso o C6 e o DevKit têm modelos independentes.

## Renderização
Malha wireframe 30x30 OpenGL ES 2.0; linhas sintéticas influenciadas pelos
desvios dos enlaces S3-C6 e S3-DevKit. Profundidade/altura e cores NÃO são
medições espaciais nem geometria real da sala. Rotação por gesto; sem câmera,
sem captura de microfone, sem upload e sem armazenamento CSI no celular.
Os dados são considerados obsoletos após 3 segundos.

## Segurança, disponibilidade e limitações
- Não expor dados de IQ antes de autenticar. Os pacotes 0x21 usam nonce único
  e a mesma sequência global dos 0x20 (inclui incremento quando UDP falha).
- Tamanho/paridade, reservado, node e replay verificados no Android.
- Fila do Wi-Fi callback finita; app guarda no máximo 2 quadros à espera da IA.
- Sem logs dos IQ ou das chaves. O APK anterior e o novo NÃO devem compartilhar
  chaves publicadas na internet; manter credenciais locais.
- NVS ainda não é proteção de segredo em repouso sem Flash Encryption em hardware.
- Secure Boot/Flash Encryption NÃO ativados automaticamente.
- 8 fps e desempenho de GPU são limites de projeto, NÃO benchmarks realizados.
- Atualização da assinatura debug pode exigir desinstalar APK anterior.

## Testes para aprovação real
1. GitHub: qualidade, Gradle :app:assembleDebug, idf.py em S3/C6/ESP32,
   verify_firmware por chip e agregação de exatamente 1 APK + 3 FULL.bin.
2. USB logs: CSI bruto no C6/DevKit, amostras >0 e nenhum reboot; medir perdas,
   heap/stack e uso de rádio com aplicativo e três placas ativos >=30 min.
3. App: modelo passa de calibrando para desvio, malha só responde a quadro fresco;
   modo avião/desligar C6 produz expiração; reconectar reautentica e recalibra.
4. Ambiente vazio, obstrução controlada, caminhar por cada enlace e repetir
   medições com posições conhecidas; medir falsos alertas sem afirmar localização.
