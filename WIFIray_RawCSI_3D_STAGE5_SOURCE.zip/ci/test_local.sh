#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/esphub-zero-build
c++ -std=c++17 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -fno-omit-frame-pointer -I shared/radar/include shared/radar/src/eh_radar.cpp shared/radar/tests/test_radar.cpp -o /tmp/esphub-zero-build/test_radar
/tmp/esphub-zero-build/test_radar
c++ -std=c++17 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -fno-omit-frame-pointer -I shared/reference/include shared/reference/tests/test_reference.cpp -o /tmp/esphub-zero-build/test_reference
/tmp/esphub-zero-build/test_reference
c++ -std=c++17 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -fno-omit-frame-pointer -I shared/wire/include shared/wire/tests/test_wire.cpp -o /tmp/esphub-zero-build/test_wire
/tmp/esphub-zero-build/test_wire
c++ -std=c++17 -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -fno-omit-frame-pointer -I shared/wire/include shared/wire/tests/test_raw_csi.cpp -o /tmp/esphub-zero-build/test_raw_csi
/tmp/esphub-zero-build/test_raw_csi
python -m unittest discover -s protocol/tests -v
python -m unittest discover -s tools/tests -v
python -m unittest discover -s ci/tests -v
if command -v kotlinc >/dev/null; then
  kotlinc -J-Xmx512m \
    android/core/src/main/kotlin/dev/esphub/zero/SecureWire.kt \
    android/core/src/main/kotlin/dev/esphub/zero/WireTelemetry.kt \
    android/core/src/main/kotlin/dev/esphub/zero/RawCsiFrame.kt \
    android/core/src/main/kotlin/dev/esphub/zero/LocalRfModel.kt \
    android/core/src/main/kotlin/dev/esphub/zero/SimulatedWaveField.kt \
    android/core/src/main/kotlin/dev/esphub/zero/LinkHealth.kt \
    android/core/src/main/kotlin/dev/esphub/zero/AuthenticatedTelemetryGate.kt \
    android/core/src/test/kotlin/dev/esphub/zero/SecureWireTest.kt \
    android/core/src/test/kotlin/dev/esphub/zero/WireTelemetryTest.kt \
    android/core/src/test/kotlin/dev/esphub/zero/LinkHealthTest.kt \
    android/core/src/test/kotlin/dev/esphub/zero/Stage3SecurityTest.kt \
    android/core/src/test/kotlin/dev/esphub/zero/AuthenticatedTelemetryGateTest.kt \
    android/core/src/test/kotlin/dev/esphub/zero/Stage4EnvelopeTest.kt \
    android/core/src/test/kotlin/dev/esphub/zero/RawCsi3dTest.kt \
    android/core/src/test/kotlin/dev/esphub/zero/RawAuthenticatedGateTest.kt \
    -include-runtime -d /tmp/esphub-zero-build/core-tests.jar
  java -cp /tmp/esphub-zero-build/core-tests.jar dev.esphub.zero.SecureWireTestKt
  java -cp /tmp/esphub-zero-build/core-tests.jar dev.esphub.zero.WireTelemetryTestKt
  java -cp /tmp/esphub-zero-build/core-tests.jar dev.esphub.zero.LinkHealthTestKt
  java -cp /tmp/esphub-zero-build/core-tests.jar dev.esphub.zero.Stage3SecurityTestKt
  java -cp /tmp/esphub-zero-build/core-tests.jar dev.esphub.zero.AuthenticatedTelemetryGateTestKt
  java -cp /tmp/esphub-zero-build/core-tests.jar dev.esphub.zero.Stage4EnvelopeTestKt
  java -cp /tmp/esphub-zero-build/core-tests.jar dev.esphub.zero.RawCsi3dTest
  java -cp /tmp/esphub-zero-build/core-tests.jar dev.esphub.zero.RawAuthenticatedGateTest
fi
# Android Gradle builds are performed separately by android-lab.yml when a new repository is available.
