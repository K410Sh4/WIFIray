# WIFIray — CSI bruto e campo de ondas 3D (Marco 5, fonte de laboratório)

Construído a partir da árvore independente de fontes auditada do WIFIray,
com derivação HKDF compatível com ESP-IDF, captura CSI bruta limitada no C6 e
no ESP32 DevKit, autenticação AES-GCM existente e visualização sintética 3D no
Android. S3 permanece emissor de referência.

**FONTE EXPERIMENTAL — não é um APK/BIN nem validação física.** A visualização 3D
não reconstrói pessoas nem coordenadas da sala. A "IA" é um modelo local
não supervisionado de padrão de rádio, sem rede neural treinada em humanos.

Documentação e protocolo: docs/STAGE5_RAW_CSI_3D.md.
Não publique chaves, senhas, dumps de flash nem arquivo local de provisionamento.
