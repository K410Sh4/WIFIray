package dev.esphub.zero

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

object RawCsi3dTest {
 @JvmStatic fun main(args:Array<String>){
    fun packet(node:Int=2,seq:Int=1,n:Int=64):ByteArray {
        val b=ByteBuffer.allocate(20+n).order(ByteOrder.BIG_ENDIAN)
        b.put(1).put(node.toByte()).put(0).put((-49).toByte())
        b.putShort(n.toShort()).putShort(0).putInt(seq).putLong(seq.toLong()*100)
        repeat(n/2){ i-> b.put((20+i%11).toByte()).put((10+i%7).toByte()) }
        return b.array()
    }
    val valid=RawCsiFrame.parse(packet())!!
    check(valid.node==2 && valid.rssi==-49 && valid.iq.size==64 && valid.serial==1L)
    check(RawCsiFrame.parse(packet().copyOf(80))==null)
    check(RawCsiFrame.parse(packet(node=1))==null)
    check(RawCsiFrame.parse(packet(seq=0))==null)
    val invalid=packet().also{it[2]=1};check(RawCsiFrame.parse(invalid)==null)
    val learner=LocalRfModel(learnFrames=3)
    check(!learner.ingest(RawCsiFrame.parse(packet(seq=1))!!)!!.ready)
    check(!learner.ingest(RawCsiFrame.parse(packet(seq=2))!!)!!.ready)
    check(!learner.ingest(RawCsiFrame.parse(packet(seq=3))!!)!!.ready)
    val ready=learner.ingest(RawCsiFrame.parse(packet(seq=4))!!)!!
    check(ready.ready && ready.anomaly<=.1f)
    check(learner.ingest(RawCsiFrame.parse(packet(seq=4))!!)==null)
    val changed=RawCsiFrame.parse(packet(seq=5).also{p->for(i in 20 until p.size step 2)p[i]=(i%7*19).toByte()})!!
    check(learner.ingest(changed)!!.anomaly>ready.anomaly)
    val none=SimulatedWaveField.sample(0f,0f,0f,null,null)
    check(none.height==0f && none.intensity==0f)
    val visible=SimulatedWaveField.sample(-.40f,0f,0f,learner.ingest(RawCsiFrame.parse(packet(seq=6).also{p->for(i in 20 until p.size step 2)p[i]=(i%7*19).toByte()})!!)!!,null)
    check(visible.intensity>none.intensity)
    check(abs(visible.height)<=.55f)
    println("Raw CSI decode, corrupt frames, replay, local learning and synthetic 3D field: PASS")
 }
}
