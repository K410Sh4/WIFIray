package dev.esphub.zero

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Authenticated raw frames share ONE sequence space with v1 status packets. */
object RawAuthenticatedGateTest {
 @JvmStatic fun main(args:Array<String>){
    val secret=ByteArray(32){(it*3+1).toByte()}
    val client=ByteArray(16){it.toByte()}
    val device=ByteArray(16){(it+31).toByte()}
    val deviceSide=SecureWire.Channel(SecureWire.derive(secret,2,client,device),2,true)
    val receiver=SecureWire.Channel(SecureWire.derive(secret,2,client,device),2,false)
    val gate=AuthenticatedTelemetryGate(2,receiver)
    fun raw(seq:Int):ByteArray{
        val b=ByteBuffer.allocate(20+64).order(ByteOrder.BIG_ENDIAN)
        b.put(1).put(2).put(0).put((-53).toByte())
        b.putShort(64).putShort(0).putInt(seq).putLong(1234)
        repeat(64){b.put((it-32).toByte())}
        return b.array()
    }
    val frame=deviceSide.seal(SecureWire.RAW_CSI,raw(7),1234)
    val damaged=frame.copyOf().also{it[it.lastIndex]=(it.last().toInt() xor 1).toByte()}
    check(gate.acceptRaw(damaged,10)==null)
    check(gate.acceptRaw(frame,11)?.serial==7L)
    check(gate.acceptRaw(frame,12)==null)
    check(gate.health.authFailures==1L && gate.health.replayed==1L)
    val wrongNode=deviceSide.seal(SecureWire.RAW_CSI,raw(8).also{it[1]=3},1234)
    check(gate.acceptRaw(wrongNode,13)==null)
    check(gate.acceptRaw(deviceSide.seal(SecureWire.RAW_CSI,raw(9),1234),14)?.serial==9L)
    println("Encrypted raw CSI, tamper, replay, node binding and shared sequence: PASS")
 }
}
