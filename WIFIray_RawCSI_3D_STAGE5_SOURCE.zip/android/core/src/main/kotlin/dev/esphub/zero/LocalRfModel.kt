package dev.esphub.zero

import kotlin.math.abs
import kotlin.math.sqrt

/** Small, on-device unsupervised reference learner: NOT a trained person detector.
 * Keeps 16 spectral-feature reference values in memory; no cloud or raw CSI logging.
 * Profiles reflect relative spectral changes; not depth or 3D position.
 */
class LocalRfModel(private val learnFrames:Int=48) {
    companion object {const val BANDS=16}
    data class Estimate(
        val node:Int,
        val serial:Long,
        val spectral:FloatArray,
        val anomaly:Float,        // relative RF anomaly; NOT human probability
        val trainingFrames:Int,
        val ready:Boolean,
    )
    private val baseline=FloatArray(BANDS)
    private val spread=FloatArray(BANDS){.04f}
    private var seen=0
    private var lastSerial=0L
    private var lastUptime=0L

    fun reset() {
        baseline.fill(0f); spread.fill(.04f);seen=0;lastSerial=0L;lastUptime=0L
    }
    fun ingest(frame:RawCsiFrame):Estimate? {
        if(frame.node !in 2..3) return null
        // Device reboot (uptime decreases) or long disconnection: never keep a
        // stale spatial reference and never reject the restarted serial forever.
        if(lastUptime!=0L &&
            (frame.uptimeMs<lastUptime || frame.uptimeMs-lastUptime>5000L))reset()
        if(frame.serial<=lastSerial)return null
        lastSerial=frame.serial
        lastUptime=frame.uptimeMs
        val power=FloatArray(BANDS)
        val counts=IntArray(BANDS)
        val pairs=frame.iq.size/2
        // Mean power per normalized frequency band. No assumption of equal carrier
        // layouts on the C6 and the classic ESP32; each has an independent model.
        for(i in 0 until pairs){
            val ii=frame.iq[2*i].toInt()
            val qq=frame.iq[2*i+1].toInt()
            val band=(i*BANDS/pairs).coerceIn(0,BANDS-1)
            power[band]+=(ii*ii+qq*qq).toFloat()
            counts[band]++
        }
        for(i in 0 until BANDS) power[i]=if(counts[i]>0) sqrt(power[i]/counts[i]) else 0f
        val level=power.average().toFloat().coerceAtLeast(1f)
        val profile=FloatArray(BANDS){(power[it]/level).coerceIn(0f,8f)}
        if(seen<learnFrames){
            seen++
            val rate=1f/seen
            for(i in 0 until BANDS)baseline[i]+=(profile[i]-baseline[i])*rate
            return Estimate(frame.node,frame.serial,FloatArray(BANDS),0f,seen,false)
        }
        val distances=FloatArray(BANDS)
        var total=0f
        for(i in 0 until BANDS){
            val diff=abs(profile[i]-baseline[i])
            val value=(diff/(.12f+spread[i]*3f)).coerceIn(0f,4f)
            distances[i]=value/4f
            total+=value
        }
        val anomaly=(total/BANDS/2f).coerceIn(0f,1f)
        // Learn only when the measured spectrum is sufficiently quiet. A strong
        // obstruction must not be immediately absorbed into the reference.
        if(anomaly<.13f){
            for(i in 0 until BANDS){
                val residual=abs(profile[i]-baseline[i])
                spread[i]+=.015f*(residual-spread[i])
                baseline[i]+=.007f*(profile[i]-baseline[i])
            }
        }
        return Estimate(frame.node,frame.serial,distances,anomaly,seen,true)
    }
}
