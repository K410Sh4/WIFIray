package dev.esphub.zero

import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sin

/** Generates a synthetic 3D wave surface conditioned by TWO measured RF links.
 * Not inverse CSI imaging, a voxel occupancy map, room geometry, or a body pose.
 */
object SimulatedWaveField {
    const val GRID=30
    data class Point(val height:Float,val intensity:Float)
    private fun segment(x:Float,z:Float,ax:Float,az:Float,bx:Float,bz:Float):Pair<Float,Float>{
        val dx=bx-ax;val dz=bz-az
        val t=(((x-ax)*dx+(z-az)*dz)/(dx*dx+dz*dz)).coerceIn(0f,1f)
        val px=ax+t*dx;val pz=az+t*dz
        val dist=(x-px)*(x-px)+(z-pz)*(z-pz)
        return dist to t
    }
    fun sample(x:Float,z:Float,phase:Float,c6:LocalRfModel.Estimate?,devkit:LocalRfModel.Estimate?):Point{
        fun contribution(model:LocalRfModel.Estimate?,endX:Float):Float {
            if(model?.ready!=true)return 0f
            val (d,t)=segment(x,z,0f,.78f,endX,-.78f)
            val shape=exp(-d*5.8f)
            val feature=model.spectral[(t*(LocalRfModel.BANDS-1)).toInt().coerceIn(0,LocalRfModel.BANDS-1)]
            return shape*(feature*.5f+model.anomaly*.8f)
        }
        val a=contribution(c6,-.82f)
        val b=contribution(devkit,.82f)
        val intensity=max(a,b).coerceIn(0f,1f)
        val oscillation=.58f+.42f*sin(phase*2.0f+z*11f+x*7f)
        return Point(intensity*oscillation*.55f,intensity)
    }
}
