package dev.esphub.zero

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Interleaved signed I/Q CSI bytes from a single receiver, NOT a spatial image. */
data class RawCsiFrame(
    val node: Int,
    val rssi: Int,
    val serial: Long,
    val uptimeMs: Long,
    val iq: ByteArray,
) {
    companion object {
        const val HEADER_SIZE=20
        const val MIN_IQ=32
        const val MAX_IQ=512
        fun parse(payload:ByteArray):RawCsiFrame? {
            if (payload.size !in (HEADER_SIZE+MIN_IQ)..(HEADER_SIZE+MAX_IQ)) return null
            val b=ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN)
            val version=b.get().toInt() and 255
            val node=b.get().toInt() and 255
            val flags=b.get().toInt() and 255
            val rssi=b.get().toInt() // signed dBm
            val count=b.short.toInt() and 65535
            val reserved=b.short.toInt() and 65535
            val serial=b.int.toLong() and 0xffffffffL
            val uptime=b.long
            if(version!=1 || node !in 2..3 || flags!=0 || reserved!=0 ||
                count !in MIN_IQ..MAX_IQ || count%2!=0 ||
                payload.size!=HEADER_SIZE+count || serial==0L || uptime<0) return null
            val iq=ByteArray(count);b.get(iq)
            return RawCsiFrame(node,rssi,serial,uptime,iq)
        }
    }
}
