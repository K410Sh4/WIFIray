package dev.esphub.zero

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Wire v1. This module deliberately has no Android dependency and can be tested on the JVM. */
object SecureWire {
    const val TELEMETRY = 0x20
    const val RAW_CSI = 0x21
    const val CONTROL = 0x30
    const val HEADER_SIZE = 30
    const val MAX_PAYLOAD = 2048
    private val prefix = byteArrayOf(0x45, 0x48, 0x55, 0x42)
    data class Keys(val sessionId: ByteArray, val deviceToApp: ByteArray, val appToDevice: ByteArray)
    data class Message(val kind: Int, val payload: ByteArray, val timestampMs: Long, val sequence: Long)
    class AuthenticationException : Exception("authentication failed")
    class ReplayException : Exception("sequence replay or out of order")

    private fun hmac(key: ByteArray, content: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        return m.doFinal(content)
    }
    fun proof(secret: ByteArray, node: Int, client: ByteArray, device: ByteArray, fromDevice: Boolean): ByteArray {
        validate(secret,node,client,device)
        val domain=if(fromDevice) "EHUB-v1/DEVICE-PROOF" else "EHUB-v1/CLIENT-PROOF"
        return hmac(secret, domain.toByteArray(Charsets.US_ASCII) + byteArrayOf(node.toByte()) + client + device)
    }
    fun verify(actual: ByteArray, expected: ByteArray) {
        if(!MessageDigest.isEqual(actual,expected)) throw AuthenticationException()
    }
    private fun validate(secret: ByteArray,node:Int,client:ByteArray,device:ByteArray) {
        require(secret.size==32 && node in 1..3 && client.size==16 && device.size==16)
    }
    fun derive(secret: ByteArray,node:Int,client:ByteArray,device:ByteArray): Keys {
        validate(secret,node,client,device)
        val prk=hmac(client+device,secret)
        val info="EHUB-v1/SESSION/".toByteArray(Charsets.US_ASCII)+byteArrayOf(node.toByte())
        var t=byteArrayOf()
        val all=ArrayList<Byte>(72)
        var round=1
        while(all.size<72) {
            t=hmac(prk,t+info+byteArrayOf(round.toByte()))
            for(b in t) all.add(b)
            round++
        }
        val keyBytes=all.take(72).toByteArray()
        return Keys(keyBytes.copyOfRange(0,8),keyBytes.copyOfRange(8,40),keyBytes.copyOfRange(40,72))
    }
    class Channel(private val keys: Keys, private val node:Int, deviceSide:Boolean) {
        private val tx=if(deviceSide) keys.deviceToApp else keys.appToDevice
        private val rx=if(deviceSide) keys.appToDevice else keys.deviceToApp
        private var nextSeq=0L
        private var lastSeq=-1L
        private var destroyed=false
        fun destroy() {
            destroyed=true
            keys.sessionId.fill(0)
            keys.deviceToApp.fill(0)
            keys.appToDevice.fill(0)
        }
        init { require(node in 1..3 && keys.sessionId.size==8 && tx.size==32 && rx.size==32) }
        fun seal(kind:Int, payload:ByteArray,timestampMs:Long,flags:Int=0):ByteArray {
            check(!destroyed) { "session destroyed" }
            require(kind==TELEMETRY||kind==RAW_CSI||kind==CONTROL)
            require(payload.size<=MAX_PAYLOAD && timestampMs>=0 && flags in 0..255)
            if(nextSeq>0xffffffffL) throw IllegalStateException("rekey required")
            val seq=nextSeq++
            val head=ByteBuffer.allocate(HEADER_SIZE).order(ByteOrder.BIG_ENDIAN)
                .put(prefix).put(1).put(kind.toByte()).put(node.toByte()).put(flags.toByte())
                .put(keys.sessionId).putInt(seq.toInt()).putLong(timestampMs)
                .putShort(payload.size.toShort()).array()
            val nonce=keys.sessionId+ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(seq.toInt()).array()
            val cipher=Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE,SecretKeySpec(tx,"AES"),GCMParameterSpec(128,nonce))
            cipher.updateAAD(head)
            return head+cipher.doFinal(payload)
        }
        fun open(frame:ByteArray):Message {
            if(destroyed || frame.size<HEADER_SIZE+16) throw AuthenticationException()
            val buffer=ByteBuffer.wrap(frame).order(ByteOrder.BIG_ENDIAN)
            val magic=ByteArray(4);buffer.get(magic)
            val version=buffer.get().toInt() and 255
            val kind=buffer.get().toInt() and 255
            val givenNode=buffer.get().toInt() and 255
            val flags=buffer.get().toInt() and 255
            val sid=ByteArray(8);buffer.get(sid)
            val seq=buffer.int.toLong() and 0xffffffffL
            val timestamp=buffer.long
            val size=buffer.short.toInt() and 0xffff
            if(!magic.contentEquals(prefix)||version!=1||kind!=TELEMETRY&&kind!=RAW_CSI&&kind!=CONTROL||
                givenNode!=node||flags!=0||timestamp<0||!sid.contentEquals(keys.sessionId)||size>MAX_PAYLOAD||
                frame.size!=HEADER_SIZE+size+16) throw AuthenticationException()
            if(seq<=lastSeq) throw ReplayException()
            val nonce=sid+ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(seq.toInt()).array()
            val cipher=Cipher.getInstance("AES/GCM/NoPadding")
            try {
                cipher.init(Cipher.DECRYPT_MODE,SecretKeySpec(rx,"AES"),GCMParameterSpec(128,nonce))
                cipher.updateAAD(frame.copyOfRange(0,HEADER_SIZE))
                val payload=cipher.doFinal(frame,HEADER_SIZE,frame.size-HEADER_SIZE)
                lastSeq=seq
                return Message(kind,payload,timestamp,seq)
            } catch (_: Exception) {
                throw AuthenticationException()
            }
        }
    }
}
