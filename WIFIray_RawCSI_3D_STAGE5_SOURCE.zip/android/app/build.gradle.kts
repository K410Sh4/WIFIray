plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace="dev.esphub.zero"
    compileSdk=35
    defaultConfig {
        applicationId="dev.esphub.zero"
        minSdk=26
        targetSdk=35
        versionCode=5
        versionName="0.5.0-raw-csi-3d-lab"
    }
    buildTypes { getByName("release") { isMinifyEnabled=false } }
    compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget="17" }
    sourceSets.getByName("main").java.srcDir("../core/src/main/kotlin")
}
