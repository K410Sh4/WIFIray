package dev.esphub.zero

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** GLES2 3D surface. Axes are illustrative; only color/height responds to CSI
 * spectral anomalies. This must NEVER be labeled as physical position/height.
 */
class WaveField3DView(context:Context):GLSurfaceView(context) {
    private val waveRenderer=WaveRenderer()
    private var lastX=0f
    init {
        setEGLContextClientVersion(2)
        setRenderer(waveRenderer)
        renderMode=RENDERMODE_WHEN_DIRTY // phone renders only on new input or UI tick
    }
    fun setEstimates(a:LocalRfModel.Estimate?,b:LocalRfModel.Estimate?){
        waveRenderer.update(a,b);requestRender()
    }
    override fun onTouchEvent(event:MotionEvent):Boolean{
        when(event.actionMasked){
            MotionEvent.ACTION_DOWN->{lastX=event.x;return true}
            MotionEvent.ACTION_MOVE->{
                val delta=(event.x-lastX)*.35f
                lastX=event.x
                waveRenderer.rotate(delta)
                requestRender();return true
            }
        }
        return true
    }
    private class WaveRenderer:Renderer {
        @Volatile private var c6:LocalRfModel.Estimate?=null
        @Volatile private var devkit:LocalRfModel.Estimate?=null
        @Volatile private var yaw=30f
        private var program=0
        private var attribPos=0
        private var attribHeat=0
        private var uniformMvp=0
        private val projection=FloatArray(16)
        private val view=FloatArray(16)
        private val model=FloatArray(16)
        private val mv=FloatArray(16)
        private val mvp=FloatArray(16)
        private val n=SimulatedWaveField.GRID
        // two endpoints * (x,y,z,heat) * two directions * (GRID-1)*GRID
        private val vertices=ByteBuffer.allocateDirect(4*4*4*(n-1)*n)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        fun update(a:LocalRfModel.Estimate?,b:LocalRfModel.Estimate?){c6=a;devkit=b}
        fun rotate(delta:Float){yaw=(yaw+delta).coerceIn(-80f,80f)}
        private fun shader(type:Int,source:String):Int{
            val id=GLES20.glCreateShader(type)
            GLES20.glShaderSource(id,source);GLES20.glCompileShader(id)
            val status=IntArray(1);GLES20.glGetShaderiv(id,GLES20.GL_COMPILE_STATUS,status,0)
            check(status[0]!=0){GLES20.glGetShaderInfoLog(id)}
            return id
        }
        override fun onSurfaceCreated(gl:GL10?,config:EGLConfig?){
            val vs=shader(GLES20.GL_VERTEX_SHADER,"""
                uniform mat4 uMvp; attribute vec3 aPos; attribute float aHeat;
                varying float vHeat;
                void main(){vHeat=aHeat;gl_Position=uMvp*vec4(aPos,1.0);}
            """.trimIndent())
            val fs=shader(GLES20.GL_FRAGMENT_SHADER,"""
                precision mediump float;varying float vHeat;
                void main(){
                    vec3 cold=vec3(0.06,0.45,0.65);
                    vec3 warm=vec3(1.0,0.28,0.08);
                    gl_FragColor=vec4(mix(cold,warm,clamp(vHeat,0.0,1.0)),0.85);
                }
            """.trimIndent())
            program=GLES20.glCreateProgram()
            GLES20.glAttachShader(program,vs);GLES20.glAttachShader(program,fs)
            GLES20.glLinkProgram(program)
            val linked=IntArray(1);GLES20.glGetProgramiv(program,GLES20.GL_LINK_STATUS,linked,0)
            check(linked[0]!=0){GLES20.glGetProgramInfoLog(program)}
            GLES20.glDeleteShader(vs);GLES20.glDeleteShader(fs)
            attribPos=GLES20.glGetAttribLocation(program,"aPos")
            attribHeat=GLES20.glGetAttribLocation(program,"aHeat")
            uniformMvp=GLES20.glGetUniformLocation(program,"uMvp")
            GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA,GLES20.GL_ONE_MINUS_SRC_ALPHA)
            GLES20.glClearColor(.025f,.04f,.075f,1f)
        }
        override fun onSurfaceChanged(gl:GL10?,width:Int,height:Int){
            GLES20.glViewport(0,0,width,height)
            Matrix.perspectiveM(projection,0,42f,width.toFloat()/height.coerceAtLeast(1),.1f,50f)
        }
        override fun onDrawFrame(gl:GL10?){
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            val a=c6;val b=devkit
            val phase=(android.os.SystemClock.elapsedRealtime()%10000L)/1000f
            fun point(ix:Int,iz:Int){
                val x=-1f+2f*ix/(n-1)
                val z=-1f+2f*iz/(n-1)
                val p=SimulatedWaveField.sample(x,z,phase,a,b)
                vertices.put(x).put(p.height).put(z).put(p.intensity)
            }
            vertices.clear()
            for(z in 0 until n)for(x in 0 until n){
                if(x+1<n){point(x,z);point(x+1,z)}
                if(z+1<n){point(x,z);point(x,z+1)}
            }
            val size=vertices.position()/4
            vertices.position(0)
            Matrix.setLookAtM(view,0,0f,2.0f,3.5f,0f,0f,0f,0f,1f,0f)
            Matrix.setIdentityM(model,0)
            Matrix.rotateM(model,0,yaw,0f,1f,0f)
            Matrix.multiplyMM(mv,0,view,0,model,0)
            Matrix.multiplyMM(mvp,0,projection,0,mv,0)
            GLES20.glUseProgram(program)
            GLES20.glUniformMatrix4fv(uniformMvp,1,false,mvp,0)
            vertices.position(0)
            GLES20.glVertexAttribPointer(attribPos,3,GLES20.GL_FLOAT,false,16,vertices)
            vertices.position(3)
            GLES20.glVertexAttribPointer(attribHeat,1,GLES20.GL_FLOAT,false,16,vertices)
            GLES20.glEnableVertexAttribArray(attribPos)
            GLES20.glEnableVertexAttribArray(attribHeat)
            GLES20.glDrawArrays(GLES20.GL_LINES,0,size)
            GLES20.glDisableVertexAttribArray(attribPos)
            GLES20.glDisableVertexAttribArray(attribHeat)
        }
    }
}
